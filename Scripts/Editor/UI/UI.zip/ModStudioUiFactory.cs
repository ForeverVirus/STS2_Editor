using Godot;
using STS2_Editor.Scripts.Editor.Core.Models;
using STS2_Editor.Scripts.Editor.Core.Utilities;

namespace STS2_Editor.Scripts.Editor.UI;

/// <summary>
/// Shared widget factory used by all Mod Studio UI panels.
/// Provides localized buttons, labels, lists, and layout helpers.
/// </summary>
internal static class ModStudioUiFactory
{
    private const string LocalizationKeyMeta = "modstudio_loc_key";
    private const string EntityKindMeta = "modstudio_entity_kind";

    // ── Localization shortcuts ──────────────────────────────────────

    public static string L(string key) => ModStudioLocalization.T(key);
    public static string LF(string key, params object?[] args) => ModStudioLocalization.F(key, args);
    public static string BoolText(bool v) => L(v ? "bool.true" : "bool.false");
    public static string Dual(string zh, string en) => ModStudioLocalization.IsChinese ? zh : en;

    // ── Metadata helpers ────────────────────────────────────────────

    public static void SetLocalizationKey(GodotObject node, string key)
        => node.SetMeta(LocalizationKeyMeta, key);

    public static string GetLocalizationKey(GodotObject node)
        => node.HasMeta(LocalizationKeyMeta) ? node.GetMeta(LocalizationKeyMeta).AsString() : string.Empty;

    public static void SetEntityKindMeta(GodotObject node, ModStudioEntityKind kind)
        => node.SetMeta(EntityKindMeta, kind.ToString());

    public static bool TryGetEntityKindMeta(GodotObject node, out ModStudioEntityKind kind)
    {
        kind = default;
        if (!node.HasMeta(EntityKindMeta)) return false;
        return System.Enum.TryParse(node.GetMeta(EntityKindMeta).AsString(), out kind);
    }

    // ── Widget builders ─────────────────────────────────────────────

    public static Button MakeButton(string text, System.Action onPressed, bool toggle = false)
    {
        var b = new Button
        {
            Text = text,
            ToggleMode = toggle,
            FocusMode = Control.FocusModeEnum.All,
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            CustomMinimumSize = new Vector2(0f, 30f)
        };
        b.Connect(Button.SignalName.Pressed, Callable.From(onPressed));
        return b;
    }

    public static Button MakeLocalizedButton(string key, System.Action onPressed, bool toggle = false)
    {
        var b = MakeButton(L(key), onPressed, toggle);
        SetLocalizationKey(b, key);
        return b;
    }

    public static Label MakeLabel(string text, bool expand = false)
    {
        return new Label
        {
            Text = text,
            AutowrapMode = TextServer.AutowrapMode.WordSmart,
            SizeFlagsHorizontal = expand ? Control.SizeFlags.ExpandFill : Control.SizeFlags.Fill
        };
    }

    public static Label MakeLocalizedLabel(string key, bool expand = false)
    {
        var label = MakeLabel(L(key), expand);
        SetLocalizationKey(label, key);
        return label;
    }

    public static RichTextLabel MakeDetails(string text, bool scrollActive = true, bool fitContent = false, float minHeight = 130f)
    {
        return new RichTextLabel
        {
            BbcodeEnabled = false,
            ScrollActive = scrollActive,
            FitContent = fitContent,
            AutowrapMode = TextServer.AutowrapMode.WordSmart,
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            CustomMinimumSize = new Vector2(0f, minHeight),
            Text = text
        };
    }

    public static RichTextLabel MakeLocalizedDetails(string key, bool scrollActive = true, bool fitContent = false, float minHeight = 130f)
    {
        var d = MakeDetails(L(key), scrollActive, fitContent, minHeight);
        SetLocalizationKey(d, key);
        return d;
    }

    public static Button MakeListEntry(string title, string subtitle, bool selected = false)
    {
        return new Button
        {
            Text = $"{title}\n{subtitle}",
            CustomMinimumSize = new Vector2(0f, 44f),
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            ToggleMode = true,
            ButtonPressed = selected,
            Alignment = HorizontalAlignment.Left,
            AutowrapMode = TextServer.AutowrapMode.WordSmart
        };
    }

    public static HBoxContainer MakeActionRow(params (string Key, System.Action Callback)[] actions)
    {
        var row = new HBoxContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
        row.AddThemeConstantOverride("separation", 6);
        foreach (var (key, callback) in actions)
            row.AddChild(MakeLocalizedButton(key, callback));
        return row;
    }

    public static ScrollContainer MakeScrollList(string name, out VBoxContainer list)
    {
        var scroll = new ScrollContainer
        {
            Name = $"{name}Scroll",
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill
        };
        list = new VBoxContainer
        {
            Name = name,
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill
        };
        list.AddThemeConstantOverride("separation", 6);
        scroll.AddChild(list);
        return scroll;
    }

    public static MarginContainer MakeFillTab(string name, out VBoxContainer content)
    {
        var tab = new MarginContainer
        {
            Name = name,
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill
        };
        tab.AddThemeConstantOverride("margin_left", 4);
        tab.AddThemeConstantOverride("margin_top", 4);
        tab.AddThemeConstantOverride("margin_right", 4);
        tab.AddThemeConstantOverride("margin_bottom", 4);
        content = new VBoxContainer
        {
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill
        };
        content.AddThemeConstantOverride("separation", 8);
        tab.AddChild(content);
        return tab;
    }

    public static PanelContainer MakeColumn(string name, float stretchRatio, Control content, int margin = 10)
    {
        var panel = new PanelContainer
        {
            Name = name,
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            SizeFlagsStretchRatio = stretchRatio
        };
        var m = new MarginContainer
        {
            AnchorRight = 1f, AnchorBottom = 1f,
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            SizeFlagsVertical = Control.SizeFlags.ExpandFill
        };
        m.AddThemeConstantOverride("margin_left", margin);
        m.AddThemeConstantOverride("margin_top", margin);
        m.AddThemeConstantOverride("margin_right", margin);
        m.AddThemeConstantOverride("margin_bottom", margin);
        panel.AddChild(m);
        m.AddChild(content);
        return panel;
    }

    // ── Recursive localization ──────────────────────────────────────

    public static void ApplyLocalizationRecursive(Node node)
    {
        if (node.HasMeta(LocalizationKeyMeta))
        {
            var key = node.GetMeta(LocalizationKeyMeta).AsString();
            switch (node)
            {
                case Button button: button.Text = L(key); break;
                case Label label: label.Text = L(key); break;
                case RichTextLabel rtl: rtl.Text = L(key); break;
                case FileDialog fd: fd.Title = L(key); break;
            }
        }
        foreach (var child in node.GetChildren())
            ApplyLocalizationRecursive(child);
    }

    public static void ClearChildren(Node? node)
    {
        if (node == null) return;
        foreach (var child in node.GetChildren()) child.QueueFree();
    }
}
