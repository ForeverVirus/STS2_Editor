using System;
using System.Collections.Generic;
using Godot;
using STS2_Editor.Scripts.Editor.Core.Models;
using static STS2_Editor.Scripts.Editor.UI.ModStudioUiFactory;

namespace STS2_Editor.Scripts.Editor.UI;

internal sealed partial class ModStudioTopBar : PanelContainer
{
    private Button? _projectTabButton;
    private Button? _packageTabButton;
    private OptionButton? _projectSelector;
    private Label? _stateLabel;

    public event Action<bool>? ModeChanged;
    public event Action<string>? ProjectSelected;
    public event Action? NewProjectRequested;
    public event Action? ExportProjectRequested;
    public event Action? ImportPackageRequested;
    public event Action? RefreshRequested;
    public event Action? CloseRequested;
    public event Action<string>? LanguageChanged;

    public override void _Ready()
    {
        CustomMinimumSize = new Vector2(0f, 38f);
        SizeFlagsHorizontal = SizeFlags.ExpandFill;

        AddChild(new ColorRect
        {
            AnchorRight = 1f, AnchorBottom = 1f,
            Color = new Color(0.07f, 0.10f, 0.13f, 0.96f),
            MouseFilter = MouseFilterEnum.Ignore
        });

        var topBar = new HBoxContainer
        {
            AnchorRight = 1f, AnchorBottom = 1f,
            OffsetLeft = 8f, OffsetTop = 4f,
            OffsetRight = -8f, OffsetBottom = -4f,
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        topBar.AddThemeConstantOverride("separation", 6);
        AddChild(topBar);

        var title = MakeLocalizedLabel("mod_studio.title");
        title.CustomMinimumSize = new Vector2(110f, 0f);
        title.VerticalAlignment = VerticalAlignment.Center;
        topBar.AddChild(title);

        _projectTabButton = MakeLocalizedButton("tab.project_mode", () => ModeChanged?.Invoke(true), true);
        _packageTabButton = MakeLocalizedButton("tab.package_mode", () => ModeChanged?.Invoke(false), true);
        _projectTabButton.CustomMinimumSize = new Vector2(92f, 28f);
        _packageTabButton.CustomMinimumSize = new Vector2(92f, 28f);
        topBar.AddChild(_projectTabButton);
        topBar.AddChild(_packageTabButton);
        topBar.AddChild(new VSeparator());

        var pnlActions = new HBoxContainer();
        pnlActions.AddThemeConstantOverride("separation", 6);
        topBar.AddChild(pnlActions);

        _projectSelector = new OptionButton { CustomMinimumSize = new Vector2(200f, 28f) };
        _projectSelector.ItemSelected += index => ProjectSelected?.Invoke(_projectSelector.GetItemMetadata((int)index).AsString());
        pnlActions.AddChild(_projectSelector);

        pnlActions.AddChild(MakeLocalizedButton("button.new", () => NewProjectRequested?.Invoke()));
        pnlActions.AddChild(MakeLocalizedButton("button.export_install", () => ExportProjectRequested?.Invoke()));
        pnlActions.AddChild(MakeLocalizedButton("button.import", () => ImportPackageRequested?.Invoke()));
        pnlActions.AddChild(MakeLocalizedButton("button.refresh", () => RefreshRequested?.Invoke()));

        topBar.AddChild(new Control { SizeFlagsHorizontal = SizeFlags.ExpandFill });

        _stateLabel = MakeLabel("");
        _stateLabel.HorizontalAlignment = HorizontalAlignment.Right;
        _stateLabel.VerticalAlignment = VerticalAlignment.Center;
        topBar.AddChild(_stateLabel);

        topBar.AddChild(MakeLocalizedButton("language.zh", () => LanguageChanged?.Invoke("zh")));
        topBar.AddChild(MakeLocalizedButton("language.en", () => LanguageChanged?.Invoke("en")));

        var closeBtn = MakeLocalizedButton("button.close_editor", () => CloseRequested?.Invoke());
        closeBtn.CustomMinimumSize = new Vector2(72f, 28f);
        topBar.AddChild(closeBtn);
        
        SetMode(true);
    }

    public void SetMode(bool isProjectMode)
    {
        if (_projectTabButton != null) _projectTabButton.ButtonPressed = isProjectMode;
        if (_packageTabButton != null) _packageTabButton.ButtonPressed = !isProjectMode;
    }

    public void SetProjects(IReadOnlyList<EditorProjectManifest> projects, string? currentId)
    {
        if (_projectSelector == null) return;
        _projectSelector.Clear();
        if (projects.Count == 0)
        {
            _projectSelector.AddItem(L("placeholder.no_projects"));
            _projectSelector.Disabled = true;
            return;
        }

        _projectSelector.Disabled = false;
        var sel = 0;
        for (int i = 0; i < projects.Count; i++)
        {
            _projectSelector.AddItem(projects[i].Name);
            _projectSelector.SetItemMetadata(i, projects[i].ProjectId);
            if (projects[i].ProjectId == currentId) sel = i;
        }
        _projectSelector.Select(sel);
    }

    public void SetState(string status)
    {
        if (_stateLabel != null) _stateLabel.Text = status;
    }
}
