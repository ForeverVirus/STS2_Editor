using Godot;
using static STS2_Editor.Scripts.Editor.UI.ModStudioUiFactory;

namespace STS2_Editor.Scripts.Editor.UI;

internal sealed partial class ModStudioEditorPanel : MarginContainer
{
    public RichTextLabel ProjectDetails { get; private set; } = null!;
    public TabContainer WorkspaceTabs { get; private set; } = null!;
    public ModStudioBasicEditor BasicEditor { get; private set; } = null!;
    public ModStudioAssetEditor AssetEditor { get; private set; } = null!;
    public ModStudioGraphEditor GraphEditor { get; private set; } = null!;

    public event System.Action<int>? TabChanged;

    public override void _Ready()
    {
        var root = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        root.AddThemeConstantOverride("separation", 8);
        AddChild(root);

        ProjectDetails = MakeLocalizedDetails("placeholder.no_workspace_project", scrollActive: false, fitContent: true, minHeight: 56f);
        root.AddChild(ProjectDetails);

        WorkspaceTabs = new TabContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        WorkspaceTabs.TabChanged += i => TabChanged?.Invoke((int)i);
        root.AddChild(WorkspaceTabs);

        var basicTab = MakeFillTab("BasicTab", out var basicContent);
        BasicEditor = new ModStudioBasicEditor();
        basicContent.AddChild(BasicEditor);
        WorkspaceTabs.AddChild(basicTab);

        var assetTab = MakeFillTab("AssetsTab", out var assetContent);
        AssetEditor = new ModStudioAssetEditor();
        assetContent.AddChild(AssetEditor);
        WorkspaceTabs.AddChild(assetTab);

        var graphTab = MakeFillTab("GraphTab", out var graphContent);
        GraphEditor = new ModStudioGraphEditor();
        graphContent.AddChild(GraphEditor);
        WorkspaceTabs.AddChild(graphTab);

        RefreshTabTitles();
    }

    public void RefreshTabTitles()
    {
        if (WorkspaceTabs.GetTabCount() > 0) WorkspaceTabs.SetTabTitle(0, L("tab.basic"));
        if (WorkspaceTabs.GetTabCount() > 1) WorkspaceTabs.SetTabTitle(1, L("tab.assets"));
        if (WorkspaceTabs.GetTabCount() > 2) WorkspaceTabs.SetTabTitle(2, L("tab.graph"));
    }
}
