using Godot;
using static STS2_Editor.Scripts.Editor.UI.ModStudioUiFactory;

namespace STS2_Editor.Scripts.Editor.UI;

internal sealed partial class ModStudioBasicEditor : MarginContainer
{
    public TextEdit MetadataEdit { get; private set; } = null!;
    public TextEdit NotesEdit { get; private set; } = null!;
    public VBoxContainer MetadataFieldList { get; private set; } = null!;

    public event System.Action? CaptureRuntimeRequested;
    public event System.Action? ApplyEventTemplateRequested;
    public event System.Action? SaveRequested;
    public event System.Action? RemoveRequested;
    public event System.Action<string>? MetadataChanged;

    public override void _Ready()
    {
        var root = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        root.AddThemeConstantOverride("separation", 8);
        AddChild(root);

        root.AddChild(MakeActionRow(
            ("button.capture_runtime", () => CaptureRuntimeRequested?.Invoke()),
            ("button.apply_event_template_scaffold", () => ApplyEventTemplateRequested?.Invoke()),
            ("button.save_override", () => SaveRequested?.Invoke()),
            ("button.remove_override", () => RemoveRequested?.Invoke())));

        var split = new HSplitContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        split.AddThemeConstantOverride("separation", 10);
        root.AddChild(split);

        var left = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.Fill, SizeFlagsVertical = SizeFlags.ExpandFill, SizeFlagsStretchRatio = 4f };
        left.AddThemeConstantOverride("separation", 6);
        left.AddChild(MakeLocalizedLabel("label.structured_fields"));
        var fieldScroll = new ScrollContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        MetadataFieldList = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        MetadataFieldList.AddThemeConstantOverride("separation", 8);
        fieldScroll.AddChild(MetadataFieldList);
        left.AddChild(fieldScroll);
        split.AddChild(left);

        var right = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill, SizeFlagsStretchRatio = 3f };
        right.AddThemeConstantOverride("separation", 6);
        right.AddChild(MakeLocalizedLabel("label.advanced_json"));
        MetadataEdit = new TextEdit { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        MetadataEdit.TextChanged += () => MetadataChanged?.Invoke(MetadataEdit.Text);
        right.AddChild(MetadataEdit);
        right.AddChild(MakeLocalizedLabel("label.notes"));
        NotesEdit = new TextEdit { CustomMinimumSize = new Vector2(0f, 160f), SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.Fill };
        right.AddChild(NotesEdit);
        split.AddChild(right);
    }
}
