using System.Collections.Generic;
using Godot;
using STS2_Editor.Scripts.Editor.Core.Models;
using static STS2_Editor.Scripts.Editor.UI.ModStudioUiFactory;

namespace STS2_Editor.Scripts.Editor.UI;

internal sealed partial class ModStudioPackagePage : MarginContainer
{
    public VBoxContainer PackageList { get; private set; } = null!;
    public RichTextLabel PackageDetails { get; private set; } = null!;
    public RichTextLabel ConflictDetails { get; private set; } = null!;

    public event System.Action? ImportRequested;
    public event System.Action? RefreshRequested;
    public event System.Action? ToggleRequested;
    public event System.Action<int>? MoveRequested;
    public event System.Action<string>? PackageSelected;

    public override void _Ready()
    {
        var root = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        root.AddThemeConstantOverride("separation", 8);
        AddChild(root);
        root.AddChild(MakeActionRow(
            ("button.import", () => ImportRequested?.Invoke()),
            ("button.refresh", () => RefreshRequested?.Invoke()),
            ("button.enable_disable", () => ToggleRequested?.Invoke()),
            ("button.move_up", () => MoveRequested?.Invoke(-1)),
            ("button.move_down", () => MoveRequested?.Invoke(1))));

        var split = new HSplitContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        root.AddChild(split);

        var left = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.Fill, SizeFlagsVertical = SizeFlags.ExpandFill, CustomMinimumSize = new Vector2(420f, 0f) };
        left.AddThemeConstantOverride("separation", 8);
        left.AddChild(MakeLocalizedLabel("label.installed_packages"));
        left.AddChild(MakeLocalizedDetails("placeholder.package_intro", scrollActive: false, fitContent: true));
        left.AddChild(MakeScrollList("PackageList", out var list));
        PackageList = list;
        split.AddChild(left);

        var right = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        right.AddThemeConstantOverride("separation", 8);
        right.AddChild(MakeLocalizedLabel("label.package_details"));
        PackageDetails = MakeLocalizedDetails("placeholder.package_intro");
        right.AddChild(PackageDetails);
        right.AddChild(MakeLocalizedLabel("label.package_conflicts"));
        ConflictDetails = MakeLocalizedDetails("placeholder.package_conflicts_intro");
        right.AddChild(ConflictDetails);
        split.AddChild(right);
    }

    public void SetPackages(IReadOnlyList<PackageSessionState> packages, string? selectedKey)
    {
        ClearChildren(PackageList);
        if (packages.Count == 0)
        {
            PackageList.AddChild(MakeListEntry(L("placeholder.no_packages"), L("placeholder.no_packages_hint")));
            return;
        }

        foreach (var package in packages)
        {
            var subtitle = $"#{package.LoadOrder} | {L("list.enabled")} {BoolText(package.Enabled)} | {L("list.session_enabled")} {BoolText(package.SessionEnabled)}";
            var button = MakeListEntry(package.DisplayName, subtitle, package.PackageKey == selectedKey);
            button.Pressed += () => PackageSelected?.Invoke(package.PackageKey);
            PackageList.AddChild(button);
        }
    }
}
