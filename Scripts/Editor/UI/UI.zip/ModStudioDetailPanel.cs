using Godot;
using static STS2_Editor.Scripts.Editor.UI.ModStudioUiFactory;

namespace STS2_Editor.Scripts.Editor.UI;

internal sealed partial class ModStudioDetailPanel : MarginContainer
{
    public event System.Action? ApplyAssetPathRequested;
    public event System.Action? ImportExternalAssetRequested;
    public event System.Action? ClearAssetRequested;
    public event System.Action? SaveGraphRequested;

    public TabContainer DetailTabs { get; private set; } = null!;

    public RichTextLabel BasicObjectDetails { get; private set; } = null!;
    public RichTextLabel BasicProjectDetails { get; private set; } = null!;

    public RichTextLabel AssetBindingDetails { get; private set; } = null!;
    public LineEdit AssetPathEdit { get; private set; } = null!;
    public TabContainer AssetTabs { get; private set; } = null!;
    public VBoxContainer RuntimeAssetList { get; private set; } = null!;
    public RichTextLabel RuntimeAssetDetails { get; private set; } = null!;
    public VBoxContainer ProjectAssetList { get; private set; } = null!;
    public RichTextLabel ProjectAssetDetails { get; private set; } = null!;
    public LineEdit AssetCatalogFilterEdit { get; private set; } = null!;

    public Label GraphNodeTypeLabel { get; private set; } = null!;
    public Label GraphNodeIdLabel { get; private set; } = null!;
    public LineEdit GraphNodeDisplayNameEdit { get; private set; } = null!;
    public TextEdit GraphNodeDescriptionEdit { get; private set; } = null!;
    public VBoxContainer GraphNodePropertyList { get; private set; } = null!;
    public CheckButton GraphToggle { get; private set; } = null!;
    public LineEdit GraphIdEdit { get; private set; } = null!;
    public VBoxContainer GraphTemplateList { get; private set; } = null!;
    public RichTextLabel GraphValidationDetails { get; private set; } = null!;
    public RichTextLabel GraphCatalogDetails { get; private set; } = null!;
    public TextEdit GraphJsonEdit { get; private set; } = null!;

    public override void _Ready()
    {
        var root = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        root.AddThemeConstantOverride("separation", 8);
        AddChild(root);
        root.AddChild(MakeLocalizedLabel("label.details_panel", true));

        DetailTabs = new TabContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill, TabsVisible = false };
        root.AddChild(DetailTabs);
        DetailTabs.AddChild(BuildBasicTab());
        DetailTabs.AddChild(BuildAssetTab());
        DetailTabs.AddChild(BuildGraphTab());
        RefreshTabTitles();
    }

    public void SyncToWorkspaceTab(int tabIndex)
    {
        if (DetailTabs.CurrentTab != tabIndex)
            DetailTabs.CurrentTab = Mathf.Clamp(tabIndex, 0, DetailTabs.GetTabCount() - 1);
    }

    public void RefreshTabTitles()
    {
        if (DetailTabs.GetTabCount() > 0) DetailTabs.SetTabTitle(0, L("tab.details"));
        if (DetailTabs.GetTabCount() > 1) DetailTabs.SetTabTitle(1, L("tab.assets"));
        if (DetailTabs.GetTabCount() > 2) DetailTabs.SetTabTitle(2, L("tab.graph"));
        if (AssetTabs != null)
        {
            if (AssetTabs.GetTabCount() > 0) AssetTabs.SetTabTitle(0, L("tab.asset_current"));
            if (AssetTabs.GetTabCount() > 1) AssetTabs.SetTabTitle(1, L("tab.asset_runtime"));
            if (AssetTabs.GetTabCount() > 2) AssetTabs.SetTabTitle(2, L("tab.asset_project"));
        }
    }

    private Control BuildBasicTab()
    {
        var tab = MakeFillTab("BasicDetailsTab", out var content);
        content.AddChild(MakeLocalizedLabel("label.selected_object"));
        BasicObjectDetails = MakeLocalizedDetails("placeholder.browser_intro", minHeight: 260f);
        content.AddChild(BasicObjectDetails);
        content.AddChild(MakeLocalizedLabel("label.workspace_project"));
        BasicProjectDetails = MakeLocalizedDetails("placeholder.no_workspace_project", scrollActive: false, fitContent: true, minHeight: 140f);
        content.AddChild(BasicProjectDetails);
        return tab;
    }

    private Control BuildAssetTab()
    {
        var tab = MakeFillTab("AssetDetailsTab", out var content);
        content.AddChild(MakeLocalizedLabel("label.asset_binding"));
        AssetBindingDetails = MakeLocalizedDetails("placeholder.asset_binding_intro", scrollActive: false, fitContent: true, minHeight: 124f);
        content.AddChild(AssetBindingDetails);
        content.AddChild(MakeLocalizedLabel("label.asset_binding_path"));
        AssetPathEdit = new LineEdit { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        content.AddChild(AssetPathEdit);
        content.AddChild(MakeActionRow(
            ("button.apply_asset_path", () => ApplyAssetPathRequested?.Invoke()),
            ("button.import_external_asset", () => ImportExternalAssetRequested?.Invoke()),
            ("button.clear_asset_override", () => ClearAssetRequested?.Invoke())));

        AssetTabs = new TabContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        content.AddChild(AssetTabs);

        var currentTab = MakeFillTab("AssetCurrentTab", out var currentContent);
        currentContent.AddChild(MakeLocalizedDetails("placeholder.asset_compare_intro", scrollActive: false, fitContent: true, minHeight: 180f));
        AssetTabs.AddChild(currentTab);

        var runtimeTab = MakeFillTab("AssetRuntimeTab", out var runtimeContent);
        AssetCatalogFilterEdit = new LineEdit { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        runtimeContent.AddChild(AssetCatalogFilterEdit);
        runtimeContent.AddChild(MakeLocalizedLabel("label.asset_catalog"));
        runtimeContent.AddChild(MakeScrollList("RuntimeAssetCatalogList", out var runtimeList));
        RuntimeAssetList = runtimeList;
        RuntimeAssetDetails = MakeLocalizedDetails("placeholder.asset_runtime_select", scrollActive: false, fitContent: true, minHeight: 90f);
        runtimeContent.AddChild(RuntimeAssetDetails);
        AssetTabs.AddChild(runtimeTab);

        var projectTab = MakeFillTab("AssetProjectTab", out var projectContent);
        projectContent.AddChild(MakeLocalizedLabel("label.project_asset_library"));
        projectContent.AddChild(MakeScrollList("ProjectAssetLibraryList", out var projectList));
        ProjectAssetList = projectList;
        ProjectAssetDetails = MakeLocalizedDetails("placeholder.asset_project_select", scrollActive: false, fitContent: true, minHeight: 90f);
        projectContent.AddChild(ProjectAssetDetails);
        AssetTabs.AddChild(projectTab);

        return tab;
    }

    private Control BuildGraphTab()
    {
        var tab = MakeFillTab("GraphDetailsTab", out var content);
        GraphNodeTypeLabel = MakeLabel(L("placeholder.graph_node_type"), true);
        GraphNodeIdLabel = MakeLabel(L("placeholder.graph_node_id"), true);
        content.AddChild(GraphNodeTypeLabel);
        content.AddChild(GraphNodeIdLabel);
        GraphNodeDisplayNameEdit = new LineEdit { SizeFlagsHorizontal = SizeFlags.ExpandFill, PlaceholderText = L("label.name") };
        content.AddChild(GraphNodeDisplayNameEdit);
        GraphNodeDescriptionEdit = new TextEdit { CustomMinimumSize = new Vector2(0f, 80f), SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.Fill };
        content.AddChild(GraphNodeDescriptionEdit);
        content.AddChild(MakeLocalizedLabel("label.node_properties"));
        var propertyScroll = new ScrollContainer { CustomMinimumSize = new Vector2(0f, 140f), SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.Fill };
        GraphNodePropertyList = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        GraphNodePropertyList.AddThemeConstantOverride("separation", 6);
        propertyScroll.AddChild(GraphNodePropertyList);
        content.AddChild(propertyScroll);
        GraphToggle = new CheckButton { Text = L("button.use_graph_behavior"), SizeFlagsHorizontal = SizeFlags.ExpandFill };
        content.AddChild(GraphToggle);
        content.AddChild(MakeLocalizedLabel("label.graph_id"));
        GraphIdEdit = new LineEdit { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        content.AddChild(GraphIdEdit);
        content.AddChild(MakeActionRow(("button.save_graph", () => SaveGraphRequested?.Invoke())));
        content.AddChild(MakeLocalizedLabel("label.quick_presets"));
        var templateScroll = new ScrollContainer { CustomMinimumSize = new Vector2(0f, 120f), SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.Fill };
        GraphTemplateList = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        GraphTemplateList.AddThemeConstantOverride("separation", 6);
        templateScroll.AddChild(GraphTemplateList);
        content.AddChild(templateScroll);
        content.AddChild(MakeLocalizedLabel("label.graph_validation"));
        GraphValidationDetails = MakeLocalizedDetails("placeholder.graph_validation_intro", minHeight: 104f);
        content.AddChild(GraphValidationDetails);
        content.AddChild(MakeLocalizedLabel("label.node_catalog"));
        GraphCatalogDetails = MakeLocalizedDetails("placeholder.node_catalog_intro", minHeight: 120f);
        content.AddChild(GraphCatalogDetails);
        content.AddChild(MakeLocalizedLabel("label.graph_json"));
        GraphJsonEdit = new TextEdit { CustomMinimumSize = new Vector2(0f, 160f), SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.Fill };
        content.AddChild(GraphJsonEdit);
        return tab;
    }
}
