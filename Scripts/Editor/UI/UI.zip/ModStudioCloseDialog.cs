using Godot;
using STS2_Editor.Scripts.Editor.Core.Utilities;
using static STS2_Editor.Scripts.Editor.UI.ModStudioUiFactory;

namespace STS2_Editor.Scripts.Editor.UI;

/// <summary>
/// Modal overlay shown when the user tries to exit the editor with unsaved changes.
/// Provides Save-and-Exit, Discard-and-Exit, Cancel actions.
/// </summary>
internal sealed partial class ModStudioCloseDialog : Control
{
    public event System.Action? SaveAndExit;
    public event System.Action? DiscardAndExit;
    public event System.Action? Cancel;

    public override void _Ready()
    {
        Visible = false;
        MouseFilter = MouseFilterEnum.Stop;
        SetAnchorsPreset(LayoutPreset.FullRect);
        SizeFlagsHorizontal = SizeFlags.ExpandFill;
        SizeFlagsVertical = SizeFlags.ExpandFill;

        // Dim background
        AddChild(new ColorRect
        {
            AnchorRight = 1f, AnchorBottom = 1f,
            Color = new Color(0f, 0f, 0f, 0.62f),
            MouseFilter = MouseFilterEnum.Stop
        });

        var center = new CenterContainer
        {
            AnchorRight = 1f, AnchorBottom = 1f,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        AddChild(center);

        var panel = new PanelContainer { CustomMinimumSize = new Vector2(520f, 0f) };
        center.AddChild(panel);

        var margin = new MarginContainer();
        margin.AddThemeConstantOverride("margin_left", 18);
        margin.AddThemeConstantOverride("margin_top", 18);
        margin.AddThemeConstantOverride("margin_right", 18);
        margin.AddThemeConstantOverride("margin_bottom", 18);
        panel.AddChild(margin);

        var content = new VBoxContainer();
        content.AddThemeConstantOverride("separation", 12);
        margin.AddChild(content);

        content.AddChild(MakeLocalizedLabel("dialog.unsaved_changes_title", true));

        var body = MakeLocalizedDetails("dialog.unsaved_changes_body", scrollActive: false, fitContent: true, minHeight: 72f);
        content.AddChild(body);

        var actions = new HBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        actions.AddThemeConstantOverride("separation", 8);
        actions.AddChild(MakeLocalizedButton("button.save_and_exit", () => SaveAndExit?.Invoke()));
        actions.AddChild(MakeLocalizedButton("button.discard_and_exit", () => DiscardAndExit?.Invoke()));
        actions.AddChild(MakeLocalizedButton("button.cancel_close", () => Cancel?.Invoke()));
        content.AddChild(actions);
    }

    public new void Show() => Visible = true;
    public new void Hide() => Visible = false;
}
