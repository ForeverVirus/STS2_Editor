using Godot;
using STS2_Editor.Scripts.Editor.Core.Utilities;

namespace STS2_Editor.Scripts.Editor.UI;

/// <summary>
/// Texture loading helper — supports res://, user://, and absolute file paths.
/// </summary>
internal static class ModStudioPreviewHelper
{
    public static Texture2D? LoadPreviewTexture(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
            return null;

        var normalized = ModStudioAssetReference.NormalizeReferencePath(path);
        if (string.IsNullOrWhiteSpace(normalized))
            return null;

        try
        {
            if (normalized.StartsWith("res://", System.StringComparison.OrdinalIgnoreCase))
                return ResourceLoader.Load<Texture2D>(normalized, null, ResourceLoader.CacheMode.Reuse);

            if (normalized.StartsWith("user://", System.StringComparison.OrdinalIgnoreCase))
                return ResourceLoader.Load<Texture2D>(ProjectSettings.GlobalizePath(normalized), null, ResourceLoader.CacheMode.Reuse);

            if (System.IO.Path.IsPathRooted(normalized) && System.IO.File.Exists(normalized))
            {
                var image = Image.LoadFromFile(normalized);
                return ImageTexture.CreateFromImage(image);
            }
        }
        catch { /* Intentionally swallowed – return null for unloadable textures. */ }

        return null;
    }
}
