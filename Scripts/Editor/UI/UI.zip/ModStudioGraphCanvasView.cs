using System.Globalization;
using System.Text;
using Godot;
using STS2_Editor.Scripts.Editor.Core.Utilities;
using STS2_Editor.Scripts.Editor.Graph;

namespace STS2_Editor.Scripts.Editor.UI;

public sealed partial class ModStudioGraphCanvasView : Control
{
    private const string LayoutKeyPrefix = "layout.node.";
    private const float AutoLayoutHorizontalSpacing = 280f;
    private const float AutoLayoutVerticalSpacing = 160f;

    private readonly Dictionary<string, GraphNode> _nodeViews = new(StringComparer.Ordinal);
    private readonly Dictionary<string, Vector2> _lastKnownPositions = new(StringComparer.Ordinal);
    private readonly Dictionary<string, NodeSlotMap> _slotMaps = new(StringComparer.Ordinal);

    private bool _graphChangeNotificationQueued;
    private bool _suppressInspectorSignals;
    private GraphEdit? _graphEdit;
    private OptionButton? _nodeTypePicker;
    private Button? _addNodeButton;
    private Button? _deleteNodeButton;
    private Button? _autoLayoutButton;
    private RichTextLabel? _graphSummaryPanel;
    private Label? _selectedNodeHeader;
    private Label? _selectedNodeTypeLabel;
    private Label? _selectedNodeIdLabel;
    private LineEdit? _displayNameEdit;
    private TextEdit? _descriptionEdit;
    private VBoxContainer? _propertyList;
    private Label? _propertyHintLabel;
    private Button? _addPropertyButton;
    private BehaviorGraphDefinition? _graph;
    private BehaviorGraphRegistry? _registry;
    private string? _selectedNodeId;
    private bool _isReady;
    private bool _isApplyingLayout;
    private bool _layoutSnapshotInitialized;

    public BehaviorGraphDefinition? BoundGraph => _graph;
    public string? SelectedNodeId => _selectedNodeId;
    public event Action<BehaviorGraphDefinition>? GraphChanged;
    public event Action<string?>? SelectedNodeChanged;

    public override void _Ready()
    {
        BuildUiIfNeeded();
        _isReady = true;
        RefreshNodeTypeCatalog();
        RebuildCanvas();
        SetProcess(true);
    }

    public override void _Process(double delta)
    {
        if (!_isReady || _graph == null || _isApplyingLayout || _nodeViews.Count == 0)
        {
            return;
        }

        var hasChanges = false;
        foreach (var pair in _nodeViews)
        {
            var node = pair.Value;
            var current = node.PositionOffset;
            if (!_lastKnownPositions.TryGetValue(pair.Key, out var previous) || current.DistanceTo(previous) > 0.1f)
            {
                _lastKnownPositions[pair.Key] = current;
                hasChanges = true;
            }
        }

        if (hasChanges && _layoutSnapshotInitialized)
        {
            TryExportLayout();
            NotifyGraphChanged();
        }
    }

    public void BindGraph(BehaviorGraphDefinition graph, BehaviorGraphRegistry registry)
    {
        ArgumentNullException.ThrowIfNull(graph);
        ArgumentNullException.ThrowIfNull(registry);

        _graph = graph;
        _registry = registry;
        _selectedNodeId = null;
        _layoutSnapshotInitialized = false;

        if (_isReady)
        {
            RefreshNodeTypeCatalog();
            RebuildCanvas();
        }
    }

    public void ClearBinding()
    {
        _graph = null;
        _registry = null;
        _selectedNodeId = null;
        _layoutSnapshotInitialized = false;

        if (_isReady)
        {
            RefreshNodeTypeCatalog();
            RebuildCanvas();
        }
    }

    public void RefreshNodeTypeCatalog()
    {
        if (_nodeTypePicker == null)
        {
            return;
        }

        var previousType = GetSelectedNodeType();
        _nodeTypePicker.Clear();

        var definitions = _registry?.Definitions
            .OrderBy(definition => string.IsNullOrWhiteSpace(definition.DisplayName) ? definition.NodeType : definition.DisplayName, StringComparer.OrdinalIgnoreCase)
            .ThenBy(definition => definition.NodeType, StringComparer.OrdinalIgnoreCase)
            .ToList() ?? new List<BehaviorGraphNodeDefinitionDescriptor>();

        foreach (var definition in definitions)
        {
            var displayName = string.IsNullOrWhiteSpace(definition.DisplayName) ? definition.NodeType : definition.DisplayName;
            var text = string.IsNullOrWhiteSpace(definition.Description)
                ? $"{displayName} ({definition.NodeType})"
                : $"{displayName} ({definition.NodeType}) - {definition.Description}";
            _nodeTypePicker.AddItem(text);
            var index = _nodeTypePicker.ItemCount - 1;
            _nodeTypePicker.SetItemMetadata(index, definition.NodeType);
        }

        if (_nodeTypePicker.ItemCount == 0)
        {
            _nodeTypePicker.AddItem(Dual("暂无可用节点", "No node types available"));
            _nodeTypePicker.Select(0);
            _nodeTypePicker.Disabled = true;
            if (_addNodeButton != null)
            {
                _addNodeButton.Disabled = true;
            }
            return;
        }

        _nodeTypePicker.Disabled = false;
        if (_addNodeButton != null)
        {
            _addNodeButton.Disabled = false;
        }

        var selectIndex = 0;
        if (!string.IsNullOrWhiteSpace(previousType))
        {
            for (var i = 0; i < _nodeTypePicker.ItemCount; i++)
            {
                if (string.Equals(_nodeTypePicker.GetItemMetadata(i).AsString(), previousType, StringComparison.Ordinal))
                {
                    selectIndex = i;
                    break;
                }
            }
        }

        _nodeTypePicker.Select(selectIndex);
    }

    public bool TryExportLayout()
    {
        if (_graph == null || _nodeViews.Count == 0)
        {
            return false;
        }

        foreach (var pair in _nodeViews)
        {
            var position = pair.Value.PositionOffset;
            _graph.Metadata[$"{LayoutKeyPrefix}{pair.Key}.x"] = position.X.ToString("R", CultureInfo.InvariantCulture);
            _graph.Metadata[$"{LayoutKeyPrefix}{pair.Key}.y"] = position.Y.ToString("R", CultureInfo.InvariantCulture);
            _lastKnownPositions[pair.Key] = position;
        }

        _layoutSnapshotInitialized = true;
        return true;
    }

    public void RebuildCanvas()
    {
        if (!_isReady || _graphEdit == null)
        {
            return;
        }

        _isApplyingLayout = true;
        try
        {
            ClearGraphEdit();
            _nodeViews.Clear();
            _slotMaps.Clear();
            _lastKnownPositions.Clear();

            if (_graph == null)
            {
                RefreshInspectorPanel();
                return;
            }

            var layout = BuildLayoutPlan(_graph, _registry);
            foreach (var node in _graph.Nodes)
            {
                var graphNode = BuildGraphNode(node, layout.TryGetValue(node.NodeId, out var plannedPosition) ? plannedPosition : Vector2.Zero);
                _graphEdit.AddChild(graphNode);
                _nodeViews[node.NodeId] = graphNode;
                _lastKnownPositions[node.NodeId] = graphNode.PositionOffset;
            }

            ApplyConnections();
            SelectInitialNode();
            TryExportLayout();
            RefreshInspectorPanel();
        }
        finally
        {
            _isApplyingLayout = false;
        }
    }

    private void BuildUiIfNeeded()
    {
        if (_graphEdit != null)
        {
            return;
        }

        var root = new MarginContainer
        {
            Name = "ModStudioGraphCanvasRoot",
            AnchorRight = 1f,
            AnchorBottom = 1f
        };
        root.AddThemeConstantOverride("margin_left", 12);
        root.AddThemeConstantOverride("margin_top", 12);
        root.AddThemeConstantOverride("margin_right", 12);
        root.AddThemeConstantOverride("margin_bottom", 12);
        AddChild(root);

        var outer = new VBoxContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        outer.AddThemeConstantOverride("separation", 10);
        root.AddChild(outer);

        var toolbarPanel = new PanelContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        var toolbarMargin = new MarginContainer();
        toolbarMargin.AddThemeConstantOverride("margin_left", 10);
        toolbarMargin.AddThemeConstantOverride("margin_top", 10);
        toolbarMargin.AddThemeConstantOverride("margin_right", 10);
        toolbarMargin.AddThemeConstantOverride("margin_bottom", 10);
        toolbarPanel.AddChild(toolbarMargin);

        var toolbar = new HBoxContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        toolbar.AddThemeConstantOverride("separation", 8);
        toolbarMargin.AddChild(toolbar);

        toolbar.AddChild(MakeLabel(Dual("节点类型", "Node Type")));
        _nodeTypePicker = new OptionButton
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            CustomMinimumSize = new Vector2(320f, 0f)
        };
        _nodeTypePicker.Connect(OptionButton.SignalName.ItemSelected, Callable.From<long>(OnNodeTypePickerSelected));
        toolbar.AddChild(_nodeTypePicker);

        _addNodeButton = MakeButton(Dual("新增节点", "Add Node"), () => TryAddSelectedNodeType());
        toolbar.AddChild(_addNodeButton);

        _deleteNodeButton = MakeButton(Dual("删除节点", "Delete Node"), () => DeleteSelectedNode());
        toolbar.AddChild(_deleteNodeButton);

        _autoLayoutButton = MakeButton(Dual("自动布局", "Auto Layout"), AutoLayout);
        toolbar.AddChild(_autoLayoutButton);

        var toolbarSummary = new RichTextLabel
        {
            BbcodeEnabled = false,
            ScrollActive = false,
            FitContent = true,
            AutowrapMode = TextServer.AutowrapMode.WordSmart,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.Fill,
            CustomMinimumSize = new Vector2(0f, 44f)
        };
        toolbarSummary.Text = Dual("拖拽节点后会自动保存布局。", "Dragging nodes will auto-save layout.");
        toolbar.AddChild(toolbarSummary);
        outer.AddChild(toolbarPanel);

        var graphPanel = new PanelContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        outer.AddChild(graphPanel);

        _graphEdit = new GraphEdit
        {
            Name = "BehaviorGraphEdit",
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill,
            ScrollOffset = Vector2.Zero,
            RightDisconnects = true,
            ConnectionLinesCurvature = 0.45f,
            ConnectionLinesThickness = 4f
        };
        _graphEdit.Connect(GraphEdit.SignalName.ConnectionRequest, Callable.From<StringName, int, StringName, int>(OnConnectionRequest));
        _graphEdit.Connect(GraphEdit.SignalName.DisconnectionRequest, Callable.From<StringName, int, StringName, int>(OnDisconnectionRequest));
        _graphEdit.Connect(Control.SignalName.GuiInput, Callable.From<InputEvent>(OnGraphGuiInput));
        graphPanel.AddChild(_graphEdit);
        var detailsRoot = new VBoxContainer
        {
            Visible = false,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        graphPanel.AddChild(detailsRoot);

        _graphSummaryPanel = new RichTextLabel
        {
            BbcodeEnabled = false,
            ScrollActive = false,
            FitContent = true,
            AutowrapMode = TextServer.AutowrapMode.WordSmart,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.Fill,
            CustomMinimumSize = new Vector2(0f, 76f)
        };
        detailsRoot.AddChild(_graphSummaryPanel);

        _selectedNodeHeader = MakeLabel(Dual("节点检查器", "Node Inspector"));
        detailsRoot.AddChild(_selectedNodeHeader);

        var inspectorScroll = new ScrollContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        detailsRoot.AddChild(inspectorScroll);

        var inspector = new VBoxContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        inspector.AddThemeConstantOverride("separation", 8);
        inspectorScroll.AddChild(inspector);

        _selectedNodeTypeLabel = MakeLabel(Dual("类型：", "Type:"));
        inspector.AddChild(_selectedNodeTypeLabel);

        _selectedNodeIdLabel = MakeLabel(Dual("节点 ID：", "Node Id:"));
        inspector.AddChild(_selectedNodeIdLabel);

        inspector.AddChild(MakeLabel(Dual("显示名称", "Display Name")));
        _displayNameEdit = new LineEdit
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        _displayNameEdit.Connect(LineEdit.SignalName.TextChanged, Callable.From<string>(OnDisplayNameEdited));
        inspector.AddChild(_displayNameEdit);

        inspector.AddChild(MakeLabel(Dual("描述", "Description")));
        _descriptionEdit = new TextEdit
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            CustomMinimumSize = new Vector2(0f, 120f)
        };
        _descriptionEdit.Connect(TextEdit.SignalName.TextChanged, Callable.From<string>(OnDescriptionEdited));
        inspector.AddChild(_descriptionEdit);

        var propertiesHeader = new HBoxContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        propertiesHeader.AddThemeConstantOverride("separation", 8);
        propertiesHeader.AddChild(MakeLabel(Dual("属性", "Properties"), true));
        _addPropertyButton = MakeButton(Dual("新增属性", "Add Property"), AddProperty);
        propertiesHeader.AddChild(_addPropertyButton);
        inspector.AddChild(propertiesHeader);

        _propertyHintLabel = MakeLabel(Dual("选中节点后可以直接编辑其属性。", "Select a node to edit its properties."));
        inspector.AddChild(_propertyHintLabel);

        _propertyList = new VBoxContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        _propertyList.AddThemeConstantOverride("separation", 6);
        inspector.AddChild(_propertyList);
    }

    public bool TrySelectNode(string? nodeId)
    {
        if (string.IsNullOrWhiteSpace(nodeId) || _graph == null || !_graph.Nodes.Any(node => node.NodeId == nodeId))
        {
            ClearSelection();
            return false;
        }

        SelectNode(nodeId);
        return true;
    }

    public bool TryAddNode(string nodeType)
    {
        if (_graph == null || _registry == null || string.IsNullOrWhiteSpace(nodeType))
        {
            return false;
        }

        if (!_registry.TryGetNodeDefinition(nodeType, out var descriptor) || descriptor == null)
        {
            return false;
        }

        var node = new BehaviorGraphNodeDefinition
        {
            NodeId = CreateUniqueNodeId(nodeType),
            NodeType = nodeType,
            DisplayName = string.IsNullOrWhiteSpace(descriptor.DisplayName) ? nodeType : descriptor.DisplayName,
            Description = descriptor.Description ?? string.Empty,
            Properties = new Dictionary<string, string>(descriptor.DefaultProperties, StringComparer.Ordinal)
        };

        var selectedPosition = GetSelectedNodePosition();
        var position = selectedPosition + new Vector2(260f, 100f);
        _graph.Nodes.Add(node);
        SetStoredPosition(node.NodeId, position);
        if (string.IsNullOrWhiteSpace(_graph.EntryNodeId) || nodeType.Contains("entry", StringComparison.OrdinalIgnoreCase) || _graph.Nodes.Count == 1)
        {
            _graph.EntryNodeId = node.NodeId;
        }

        RebuildCanvas();
        SelectNode(node.NodeId);
        NotifyGraphChanged();
        return true;
    }

    public bool DeleteSelectedNode()
    {
        if (_graph == null || string.IsNullOrWhiteSpace(_selectedNodeId))
        {
            return false;
        }

        var nodeId = _selectedNodeId;
        var removed = _graph.Nodes.RemoveAll(node => node.NodeId == nodeId);
        if (removed == 0)
        {
            return false;
        }

        _graph.Connections.RemoveAll(connection =>
            string.Equals(connection.FromNodeId, nodeId, StringComparison.Ordinal) ||
            string.Equals(connection.ToNodeId, nodeId, StringComparison.Ordinal));

        RemoveStoredLayout(nodeId);

        if (string.Equals(_graph.EntryNodeId, nodeId, StringComparison.Ordinal))
        {
            _graph.EntryNodeId = _graph.Nodes.FirstOrDefault()?.NodeId ?? string.Empty;
        }

        _selectedNodeId = null;
        RebuildCanvas();
        NotifyGraphChanged();
        return true;
    }

    public void AutoLayout()
    {
        if (_graph == null)
        {
            return;
        }

        var layout = BuildLayoutPlan(_graph, _registry, respectStoredLayout: false);
        foreach (var pair in layout)
        {
            SetStoredPosition(pair.Key, pair.Value);
        }

        RebuildCanvas();
        NotifyGraphChanged();
    }

    private void OnNodeTypePickerSelected(long index)
    {
        if (_nodeTypePicker == null || index < 0 || index >= _nodeTypePicker.ItemCount)
        {
            return;
        }

        if (string.IsNullOrWhiteSpace(GetSelectedNodeType()))
        {
            return;
        }
    }

    private bool TryAddSelectedNodeType()
    {
        var nodeType = GetSelectedNodeType();
        if (string.IsNullOrWhiteSpace(nodeType))
        {
            return false;
        }

        return TryAddNode(nodeType);
    }

    private string? GetSelectedNodeType()
    {
        if (_nodeTypePicker == null || _nodeTypePicker.ItemCount == 0)
        {
            return null;
        }

        var index = _nodeTypePicker.Selected;
        if (index < 0 || index >= _nodeTypePicker.ItemCount)
        {
            return null;
        }

        return _nodeTypePicker.GetItemMetadata(index).AsString();
    }

    private void NotifyGraphChanged()
    {
        if (_graph == null)
        {
            return;
        }

        if (_graphChangeNotificationQueued)
        {
            return;
        }

        _graphChangeNotificationQueued = true;
        CallDeferred(nameof(FlushGraphChanged));
    }

    private void FlushGraphChanged()
    {
        _graphChangeNotificationQueued = false;
        if (_graph == null)
        {
            return;
        }

        TryExportLayout();
        GraphChanged?.Invoke(_graph);
    }

    private void ClearSelection()
    {
        if (string.IsNullOrWhiteSpace(_selectedNodeId))
        {
            RefreshInspectorPanel();
            return;
        }

        _selectedNodeId = null;
        RefreshInspectorPanel();
        SelectedNodeChanged?.Invoke(_selectedNodeId);
    }

    private void RefreshInspectorPanel()
    {
        UpdateDetailsPanel();

        var hasSelection = _graph != null && !string.IsNullOrWhiteSpace(_selectedNodeId) && _graph.Nodes.Any(node => node.NodeId == _selectedNodeId);
        if (_selectedNodeHeader != null)
        {
            _selectedNodeHeader.Text = hasSelection ? Dual("当前节点", "Selected Node") : Dual("未选择节点", "No Node Selected");
        }

        if (_selectedNodeTypeLabel != null)
        {
            _selectedNodeTypeLabel.Text = hasSelection ? BuildSelectedNodeTypeText() : Dual("类型：-", "Type: -");
        }

        if (_selectedNodeIdLabel != null)
        {
            _selectedNodeIdLabel.Text = hasSelection ? BuildSelectedNodeIdText() : Dual("节点 ID：-", "Node Id: -");
        }

        if (_displayNameEdit != null)
        {
            _suppressInspectorSignals = true;
            try
            {
                _displayNameEdit.Text = hasSelection ? GetSelectedNode()?.DisplayName ?? string.Empty : string.Empty;
                _displayNameEdit.Editable = hasSelection;
            }
            finally
            {
                _suppressInspectorSignals = false;
            }
        }

        if (_descriptionEdit != null)
        {
            _suppressInspectorSignals = true;
            try
            {
                _descriptionEdit.Text = hasSelection ? GetSelectedNode()?.Description ?? string.Empty : string.Empty;
                _descriptionEdit.Editable = hasSelection;
            }
            finally
            {
                _suppressInspectorSignals = false;
            }
        }

        if (_deleteNodeButton != null)
        {
            _deleteNodeButton.Disabled = !hasSelection;
        }

        if (_addPropertyButton != null)
        {
            _addPropertyButton.Disabled = !hasSelection;
        }

        if (_propertyHintLabel != null)
        {
            _propertyHintLabel.Visible = !hasSelection;
        }

        RefreshPropertyEditorList();
    }

    private BehaviorGraphNodeDefinition? GetSelectedNode()
    {
        if (_graph == null || string.IsNullOrWhiteSpace(_selectedNodeId))
        {
            return null;
        }

        return _graph.Nodes.FirstOrDefault(node => node.NodeId == _selectedNodeId);
    }

    private string BuildSelectedNodeTypeText()
    {
        var node = GetSelectedNode();
        if (node == null)
        {
            return Dual("类型：-", "Type: -");
        }

        var descriptor = ResolveDescriptor(node.NodeType);
        var display = descriptor?.DisplayName ?? node.NodeType;
        return Dual($"类型：{display}", $"Type: {display}");
    }

    private string BuildSelectedNodeIdText()
    {
        var node = GetSelectedNode();
        if (node == null)
        {
            return Dual("节点 ID：-", "Node Id: -");
        }

        return Dual($"节点 ID：{node.NodeId}", $"Node Id: {node.NodeId}");
    }

    private void RefreshPropertyEditorList()
    {
        if (_propertyList == null)
        {
            return;
        }

        ClearChildren(_propertyList);

        var node = GetSelectedNode();
        if (node == null)
        {
            _propertyList.AddChild(MakeLabel(Dual("请选择一个节点。", "Select a node."), true));
            return;
        }

        if (node.Properties.Count == 0)
        {
            _propertyList.AddChild(MakeLabel(Dual("该节点当前没有属性。", "This node has no properties yet."), true));
            return;
        }

        foreach (var pair in node.Properties.OrderBy(pair => pair.Key, StringComparer.OrdinalIgnoreCase))
        {
            _propertyList.AddChild(CreatePropertyRow(pair.Key, pair.Value));
        }
    }

    private Control CreatePropertyRow(string key, string value)
    {
        var row = new VBoxContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        row.AddThemeConstantOverride("separation", 4);

        var header = new HBoxContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        header.AddThemeConstantOverride("separation", 6);
        header.AddChild(MakeLabel(Dual("属性键", "Property Key")));
        var removeButton = MakeButton(Dual("删除", "Remove"), () => RemoveProperty(key));
        header.AddChild(removeButton);
        row.AddChild(header);

        var keyEdit = new LineEdit
        {
            Text = key,
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        keyEdit.Connect(LineEdit.SignalName.TextChanged, Callable.From<string>(text => OnPropertyKeyEdited(key, text)));
        row.AddChild(keyEdit);

        var valueEdit = new LineEdit
        {
            Text = value,
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        valueEdit.Connect(LineEdit.SignalName.TextChanged, Callable.From<string>(text => OnPropertyValueEdited(key, text)));
        row.AddChild(valueEdit);

        return row;
    }

    private void OnDisplayNameEdited(string _)
    {
        if (_suppressInspectorSignals)
        {
            return;
        }

        ApplySelectedNodeEdits();
    }

    private void OnDescriptionEdited(string _)
    {
        if (_suppressInspectorSignals)
        {
            return;
        }

        ApplySelectedNodeEdits();
    }

    private void OnPropertyKeyEdited(string originalKey, string newKey)
    {
        if (_suppressInspectorSignals || _graph == null)
        {
            return;
        }

        var node = GetSelectedNode();
        if (node == null)
        {
            return;
        }

        var normalizedNewKey = newKey.Trim();
        if (string.IsNullOrWhiteSpace(normalizedNewKey) || string.Equals(originalKey, normalizedNewKey, StringComparison.Ordinal))
        {
            return;
        }

        var currentValue = node.Properties.TryGetValue(originalKey, out var value) ? value : string.Empty;
        node.Properties.Remove(originalKey);
        node.Properties[normalizedNewKey] = currentValue;
        RefreshPropertyEditorList();
        NotifyGraphChanged();
    }

    private void OnPropertyValueEdited(string key, string newValue)
    {
        if (_suppressInspectorSignals || _graph == null)
        {
            return;
        }

        var node = GetSelectedNode();
        if (node == null)
        {
            return;
        }

        node.Properties[key] = newValue;
        NotifyGraphChanged();
    }

    private void AddProperty()
    {
        var node = GetSelectedNode();
        if (node == null)
        {
            return;
        }

        var key = GenerateUniquePropertyKey(node);
        node.Properties[key] = string.Empty;
        RefreshPropertyEditorList();
        NotifyGraphChanged();
    }

    private void RemoveProperty(string key)
    {
        var node = GetSelectedNode();
        if (node == null)
        {
            return;
        }

        if (!node.Properties.Remove(key))
        {
            return;
        }

        RefreshPropertyEditorList();
        NotifyGraphChanged();
    }

    private static string GenerateUniquePropertyKey(BehaviorGraphNodeDefinition node)
    {
        var baseKey = "property";
        var index = 1;
        while (node.Properties.ContainsKey($"{baseKey}_{index}"))
        {
            index++;
        }

        return $"{baseKey}_{index}";
    }

    private static string CreateUniqueNodeId(string nodeType)
    {
        var prefixChars = nodeType
            .Select(ch => char.IsLetterOrDigit(ch) ? char.ToLowerInvariant(ch) : '_')
            .ToArray();
        var prefix = new string(prefixChars).Trim('_');
        if (string.IsNullOrWhiteSpace(prefix))
        {
            prefix = "node";
        }

        return $"{prefix}_{Guid.NewGuid():N}";
    }

    private void ApplySelectedNodeEdits()
    {
        if (_suppressInspectorSignals || _graph == null)
        {
            return;
        }

        var node = GetSelectedNode();
        if (node == null)
        {
            return;
        }

        var changed = false;

        var displayName = _displayNameEdit?.Text?.Trim() ?? string.Empty;
        if (!string.Equals(node.DisplayName, displayName, StringComparison.Ordinal))
        {
            node.DisplayName = displayName;
            UpdateNodeViewTitle(node.NodeId);
            changed = true;
        }

        var description = _descriptionEdit?.Text?.Trim() ?? string.Empty;
        if (!string.Equals(node.Description, description, StringComparison.Ordinal))
        {
            node.Description = description;
            changed = true;
        }

        if (changed)
        {
            RefreshInspectorPanel();
            NotifyGraphChanged();
        }
    }

    private void UpdateNodeViewTitle(string nodeId)
    {
        if (_nodeViews.TryGetValue(nodeId, out var nodeView) && _graph != null)
        {
            var node = _graph.Nodes.FirstOrDefault(candidate => candidate.NodeId == nodeId);
            if (node != null)
            {
                nodeView.Title = string.IsNullOrWhiteSpace(node.DisplayName) ? node.NodeType : node.DisplayName;
            }
        }
    }

    private Vector2 GetSelectedNodePosition()
    {
        var node = GetSelectedNode();
        if (node != null)
        {
            return GetNodePosition(node.NodeId);
        }

        return Vector2.Zero;
    }

    private void SetStoredPosition(string nodeId, Vector2 position)
    {
        if (_graph == null)
        {
            return;
        }

        _graph.Metadata[$"{LayoutKeyPrefix}{nodeId}.x"] = position.X.ToString("R", CultureInfo.InvariantCulture);
        _graph.Metadata[$"{LayoutKeyPrefix}{nodeId}.y"] = position.Y.ToString("R", CultureInfo.InvariantCulture);
    }

    private void RemoveStoredLayout(string nodeId)
    {
        if (_graph == null)
        {
            return;
        }

        _graph.Metadata.Remove($"{LayoutKeyPrefix}{nodeId}.x");
        _graph.Metadata.Remove($"{LayoutKeyPrefix}{nodeId}.y");
    }

    private GraphNode BuildGraphNode(BehaviorGraphNodeDefinition node, Vector2 plannedPosition)
    {
        var descriptor = ResolveDescriptor(node.NodeType);
        var graphNode = new GraphNode
        {
            Name = node.NodeId,
            Title = string.IsNullOrWhiteSpace(node.DisplayName) ? node.NodeType : node.DisplayName,
            PositionOffset = plannedPosition,
            Resizable = true,
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };

        var content = new VBoxContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        content.AddThemeConstantOverride("separation", 4);
        graphNode.AddChild(content);

        content.AddChild(MakeLabel($"Type: {node.NodeType}"));
        if (!string.IsNullOrWhiteSpace(node.Description))
        {
            content.AddChild(MakeLabel(node.Description));
        }

        if (descriptor != null)
        {
            if (descriptor.Inputs.Count > 0)
            {
                content.AddChild(MakeLabel("Inputs"));
                AddPortRows(graphNode, descriptor.Inputs, content, isInput: true, node.NodeId);
            }

            if (descriptor.Outputs.Count > 0)
            {
                content.AddChild(MakeLabel("Outputs"));
                AddPortRows(graphNode, descriptor.Outputs, content, isInput: false, node.NodeId);
            }
        }

        if (descriptor == null && node.Properties.Count == 0)
        {
            content.AddChild(MakeLabel("No descriptor found for this node type."));
        }

        if (node.Properties.Count > 0)
        {
            content.AddChild(MakeLabel("Properties"));
            foreach (var pair in node.Properties.OrderBy(pair => pair.Key, StringComparer.Ordinal))
            {
                content.AddChild(MakeLabel($"{pair.Key} = {pair.Value}"));
            }
        }

        graphNode.Connect(Control.SignalName.GuiInput, Callable.From<InputEvent>(evt => OnNodeGuiInput(node.NodeId, evt)));
        return graphNode;
    }

    private void AddPortRows(GraphNode graphNode, IReadOnlyList<BehaviorGraphPortDefinition> ports, VBoxContainer content, bool isInput, string nodeId)
    {
        var slotMap = GetOrCreateSlotMap(nodeId);
        foreach (var port in ports)
        {
            if (slotMap.TryGetSlot(port.PortId, out _))
            {
                continue;
            }

            var row = new HBoxContainer
            {
                SizeFlagsHorizontal = SizeFlags.ExpandFill
            };
            row.AddThemeConstantOverride("separation", 6);

            var indicator = new ColorRect
            {
                CustomMinimumSize = new Vector2(12f, 12f),
                Color = GetPortColor(port.ValueType)
            };
            row.AddChild(isInput ? indicator : MakeSpacer());
            row.AddChild(MakeLabel($"{port.PortId} ({port.ValueType})", expand: true));
            row.AddChild(isInput ? MakeSpacer() : indicator);
            content.AddChild(row);

            var slotIndex = slotMap.NextSlotIndex++;
            slotMap.Add(port.PortId, slotIndex, isInput);
            graphNode.SetSlot(
                slotIndex,
                isInput,
                0,
                GetPortColor(port.ValueType),
                !isInput,
                0,
                GetPortColor(port.ValueType));
        }
    }

    private void ApplyConnections()
    {
        if (_graphEdit == null || _graph == null)
        {
            return;
        }

        foreach (var connection in _graph.Connections)
        {
            if (!_nodeViews.TryGetValue(connection.FromNodeId, out var fromNode) ||
                !_nodeViews.TryGetValue(connection.ToNodeId, out var toNode))
            {
                continue;
            }

            var fromSlots = GetOrCreateSlotMap(connection.FromNodeId);
            var toSlots = GetOrCreateSlotMap(connection.ToNodeId);

            if (!fromSlots.TryGetSlot(connection.FromPortId, out var fromPortIndex))
            {
                fromPortIndex = EnsureFallbackPort(fromNode, fromSlots, connection.FromPortId, isInput: false);
            }

            if (!toSlots.TryGetSlot(connection.ToPortId, out var toPortIndex))
            {
                toPortIndex = EnsureFallbackPort(toNode, toSlots, connection.ToPortId, isInput: true);
            }

            _graphEdit.ConnectNode(connection.FromNodeId, fromPortIndex, connection.ToNodeId, toPortIndex);
        }
    }

    private int EnsureFallbackPort(GraphNode node, NodeSlotMap slotMap, string portId, bool isInput)
    {
        if (slotMap.TryGetSlot(portId, out var existing))
        {
            return existing;
        }

        var slotIndex = slotMap.NextSlotIndex++;
        slotMap.Add(portId, slotIndex, isInput);
        node.SetSlot(
            slotIndex,
            isInput,
            0,
            Colors.White,
            !isInput,
            0,
            Colors.White);
        return slotIndex;
    }

    private void ClearGraphEdit()
    {
        if (_graphEdit == null)
        {
            return;
        }

        foreach (var child in _graphEdit.GetChildren().OfType<Node>().ToList())
        {
            _graphEdit.RemoveChild(child);
            child.QueueFree();
        }
    }

    private void SelectInitialNode()
    {
        if (_graph == null)
        {
            return;
        }

        var selected = !string.IsNullOrWhiteSpace(_graph.EntryNodeId) && _nodeViews.ContainsKey(_graph.EntryNodeId)
            ? _graph.EntryNodeId
            : _graph.Nodes.FirstOrDefault()?.NodeId;

        if (!string.IsNullOrWhiteSpace(selected))
        {
            SelectNode(selected);
        }
    }

    private void SelectNode(string nodeId)
    {
        if (string.IsNullOrWhiteSpace(nodeId))
        {
            ClearSelection();
            return;
        }

        if (_selectedNodeId == nodeId)
        {
            RefreshInspectorPanel();
            return;
        }

        _selectedNodeId = nodeId;
        RefreshInspectorPanel();
        SelectedNodeChanged?.Invoke(_selectedNodeId);
    }

    private void UpdateDetailsPanel()
    {
        if (_graphSummaryPanel == null)
        {
            return;
        }

        _graphSummaryPanel.Text = BuildDetailsText();
    }

    private string BuildDetailsText()
    {
        var builder = new StringBuilder();
        if (_graph == null)
        {
            builder.AppendLine("No graph bound.");
            return builder.ToString().TrimEnd();
        }

        builder.AppendLine($"Graph: {_graph.Name}");
        builder.AppendLine($"GraphId: {_graph.GraphId}");
        builder.AppendLine($"Entry: {_graph.EntryNodeId}");
        builder.AppendLine($"Nodes: {_graph.Nodes.Count}");
        builder.AppendLine($"Connections: {_graph.Connections.Count}");
        builder.AppendLine();

        if (string.IsNullOrWhiteSpace(_selectedNodeId) || !_graph.Nodes.Any(node => node.NodeId == _selectedNodeId))
        {
            builder.AppendLine("Select a node to inspect its details.");
            return builder.ToString().TrimEnd();
        }

        var node = _graph.Nodes.First(node => node.NodeId == _selectedNodeId);
        var descriptor = ResolveDescriptor(node.NodeType);
        builder.AppendLine($"Node: {node.DisplayName}");
        builder.AppendLine($"NodeId: {node.NodeId}");
        builder.AppendLine($"NodeType: {node.NodeType}");
        builder.AppendLine($"Description: {node.Description}");
        builder.AppendLine($"Position: {GetNodePosition(node.NodeId)}");
        builder.AppendLine();

        if (descriptor != null)
        {
            builder.AppendLine("Inputs:");
            if (descriptor.Inputs.Count == 0)
            {
                builder.AppendLine("  (none)");
            }
            else
            {
                foreach (var port in descriptor.Inputs)
                {
                    builder.AppendLine($"  - {port.PortId} ({port.ValueType})");
                }
            }

            builder.AppendLine("Outputs:");
            if (descriptor.Outputs.Count == 0)
            {
                builder.AppendLine("  (none)");
            }
            else
            {
                foreach (var port in descriptor.Outputs)
                {
                    builder.AppendLine($"  - {port.PortId} ({port.ValueType})");
                }
            }
        }

        if (node.Properties.Count > 0)
        {
            builder.AppendLine("Properties:");
            foreach (var pair in node.Properties.OrderBy(pair => pair.Key, StringComparer.Ordinal))
            {
                builder.AppendLine($"  - {pair.Key} = {pair.Value}");
            }
        }

        return builder.ToString().TrimEnd();
    }

    private Vector2 GetNodePosition(string nodeId)
    {
        if (_nodeViews.TryGetValue(nodeId, out var view))
        {
            return view.PositionOffset;
        }

        return Vector2.Zero;
    }

    private void OnNodeGuiInput(string nodeId, InputEvent inputEvent)
    {
        if (inputEvent is InputEventMouseButton mouseButton &&
            mouseButton.ButtonIndex == MouseButton.Left &&
            mouseButton.Pressed)
        {
            SelectNode(nodeId);
        }
    }

    private void OnGraphGuiInput(InputEvent inputEvent)
    {
        if (inputEvent is InputEventMouseButton mouseButton &&
            mouseButton.ButtonIndex == MouseButton.Left &&
            mouseButton.Pressed)
        {
            if (FindClickedGraphNode(mouseButton.Position) == null)
            {
                ClearSelection();
            }
        }
    }

    private GraphNode? FindClickedGraphNode(Vector2 graphLocalPosition)
    {
        if (_graphEdit == null)
        {
            return null;
        }

        foreach (var node in _nodeViews.Values)
        {
            var rect = new Rect2(node.PositionOffset, node.Size);
            if (rect.HasPoint(graphLocalPosition))
            {
                return node;
            }
        }

        return null;
    }

    private void OnConnectionRequest(StringName fromNode, int fromPort, StringName toNode, int toPort)
    {
        if (_graph == null)
        {
            return;
        }

        var connection = new BehaviorGraphConnectionDefinition
        {
            FromNodeId = fromNode.ToString(),
            FromPortId = ResolvePortId(fromNode.ToString(), fromPort),
            ToNodeId = toNode.ToString(),
            ToPortId = ResolvePortId(toNode.ToString(), toPort)
        };
        _graph.Connections.Add(connection);
        _graphEdit?.ConnectNode(fromNode, fromPort, toNode, toPort);
        RefreshInspectorPanel();
        NotifyGraphChanged();
    }

    private void OnDisconnectionRequest(StringName fromNode, int fromPort, StringName toNode, int toPort)
    {
        if (_graph == null)
        {
            return;
        }

        var fromNodeId = fromNode.ToString();
        var toNodeId = toNode.ToString();
        var fromPortId = ResolvePortId(fromNodeId, fromPort);
        var toPortId = ResolvePortId(toNodeId, toPort);

        var index = _graph.Connections.FindIndex(connection =>
            connection.FromNodeId == fromNodeId &&
            connection.FromPortId == fromPortId &&
            connection.ToNodeId == toNodeId &&
            connection.ToPortId == toPortId);

        if (index >= 0)
        {
            _graph.Connections.RemoveAt(index);
            _graphEdit?.DisconnectNode(fromNode, fromPort, toNode, toPort);
            RefreshInspectorPanel();
            NotifyGraphChanged();
        }
    }

    private BehaviorGraphNodeDefinitionDescriptor? ResolveDescriptor(string nodeType)
    {
        if (_registry != null && _registry.TryGetNodeDefinition(nodeType, out var descriptor))
        {
            return descriptor;
        }

        return null;
    }

    private Dictionary<string, Vector2> BuildLayoutPlan(BehaviorGraphDefinition graph, BehaviorGraphRegistry? registry, bool respectStoredLayout = true)
    {
        var plan = new Dictionary<string, Vector2>(StringComparer.Ordinal);
        var adjacency = new Dictionary<string, List<string>>(StringComparer.Ordinal);
        var incoming = new Dictionary<string, int>(StringComparer.Ordinal);
        var nodesById = graph.Nodes.ToDictionary(node => node.NodeId, StringComparer.Ordinal);

        foreach (var node in graph.Nodes)
        {
            adjacency[node.NodeId] = new List<string>();
            incoming[node.NodeId] = 0;
        }

        foreach (var connection in graph.Connections)
        {
            if (!adjacency.TryGetValue(connection.FromNodeId, out var targets))
            {
                continue;
            }

            targets.Add(connection.ToNodeId);
            if (incoming.ContainsKey(connection.ToNodeId))
            {
                incoming[connection.ToNodeId]++;
            }
        }

        var levels = new Dictionary<string, int>(StringComparer.Ordinal);
        var queue = new Queue<string>();

        if (!string.IsNullOrWhiteSpace(graph.EntryNodeId) && nodesById.ContainsKey(graph.EntryNodeId))
        {
            queue.Enqueue(graph.EntryNodeId);
            levels[graph.EntryNodeId] = 0;
        }
        else
        {
            foreach (var node in graph.Nodes.Where(node => incoming[node.NodeId] == 0))
            {
                queue.Enqueue(node.NodeId);
                levels[node.NodeId] = 0;
            }
        }

        if (queue.Count == 0)
        {
            foreach (var node in graph.Nodes)
            {
                queue.Enqueue(node.NodeId);
                levels[node.NodeId] = 0;
            }
        }

        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            var currentLevel = levels[current];
            foreach (var next in adjacency[current])
            {
                var nextLevel = currentLevel + 1;
                if (!levels.TryGetValue(next, out var existing) || nextLevel > existing)
                {
                    levels[next] = nextLevel;
                    queue.Enqueue(next);
                }
            }
        }

        foreach (var node in graph.Nodes)
        {
            if (levels.ContainsKey(node.NodeId))
            {
                continue;
            }

            levels[node.NodeId] = incoming.TryGetValue(node.NodeId, out var inCount) && inCount == 0 ? 0 : 1;
        }

        var grouped = levels
            .GroupBy(pair => pair.Value)
            .OrderBy(group => group.Key)
            .ToDictionary(
                group => group.Key,
                group => group.Select(pair => pair.Key).OrderBy(nodeId => nodesById[nodeId].DisplayName, StringComparer.Ordinal).ThenBy(nodeId => nodeId, StringComparer.Ordinal).ToList());

        foreach (var group in grouped)
        {
            for (var index = 0; index < group.Value.Count; index++)
            {
                var nodeId = group.Value[index];
                var x = group.Key * AutoLayoutHorizontalSpacing;
                var y = index * AutoLayoutVerticalSpacing;
                plan[nodeId] = new Vector2(x, y);
            }
        }

        if (respectStoredLayout)
        {
            foreach (var node in graph.Nodes)
            {
                if (TryReadStoredPosition(graph, node.NodeId, out var stored))
                {
                    plan[node.NodeId] = stored;
                }
            }
        }

        return plan;
    }

    private static bool TryReadStoredPosition(BehaviorGraphDefinition graph, string nodeId, out Vector2 position)
    {
        position = Vector2.Zero;
        var xKey = $"{LayoutKeyPrefix}{nodeId}.x";
        var yKey = $"{LayoutKeyPrefix}{nodeId}.y";
        if (!graph.Metadata.TryGetValue(xKey, out var xValue) || !graph.Metadata.TryGetValue(yKey, out var yValue))
        {
            return false;
        }

        if (!float.TryParse(xValue, NumberStyles.Float, CultureInfo.InvariantCulture, out var x) ||
            !float.TryParse(yValue, NumberStyles.Float, CultureInfo.InvariantCulture, out var y))
        {
            return false;
        }

        position = new Vector2(x, y);
        return true;
    }

    private string ResolvePortId(string nodeId, int slotIndex)
    {
        var slotMap = GetOrCreateSlotMap(nodeId);
        return slotMap.TryGetPortId(slotIndex, out var portId) ? portId : slotIndex.ToString(CultureInfo.InvariantCulture);
    }

    private NodeSlotMap GetOrCreateSlotMap(string nodeId)
    {
        if (_slotMaps.TryGetValue(nodeId, out var slotMap))
        {
            return slotMap;
        }

        slotMap = new NodeSlotMap();
        _slotMaps[nodeId] = slotMap;
        return slotMap;
    }

    private static Label MakeLabel(string text, bool expand = false)
    {
        return new Label
        {
            Text = text,
            AutowrapMode = TextServer.AutowrapMode.WordSmart,
            SizeFlagsHorizontal = expand ? SizeFlags.ExpandFill : SizeFlags.ShrinkCenter
        };
    }

    private Button MakeButton(string text, Action onPressed, bool toggle = false)
    {
        var button = new Button
        {
            Text = text,
            ToggleMode = toggle,
            FocusMode = Control.FocusModeEnum.All,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            CustomMinimumSize = new Vector2(0f, 34f)
        };
        button.Connect(Button.SignalName.Pressed, Callable.From(onPressed));
        return button;
    }

    private static void ClearChildren(Node? node)
    {
        if (node == null)
        {
            return;
        }

        foreach (var child in node.GetChildren().OfType<Node>().ToList())
        {
            node.RemoveChild(child);
            child.QueueFree();
        }
    }

    private static Control MakeSpacer()
    {
        return new Control
        {
            CustomMinimumSize = new Vector2(12f, 12f)
        };
    }

    private static string Dual(string zh, string en)
    {
        return ModStudioLocalization.IsChinese ? zh : en;
    }

    private static Color GetPortColor(string valueType)
    {
        var normalized = string.IsNullOrWhiteSpace(valueType) ? "flow" : valueType.Trim().ToLowerInvariant();
        return normalized switch
        {
            "flow" => new Color(0.36f, 0.69f, 0.96f),
            "bool" => new Color(0.40f, 0.76f, 0.54f),
            "int" => new Color(0.95f, 0.67f, 0.26f),
            "float" => new Color(0.95f, 0.52f, 0.38f),
            "string" => new Color(0.81f, 0.70f, 0.96f),
            _ => new Color(0.73f, 0.73f, 0.73f)
        };
    }

    private sealed class NodeSlotMap
    {
        private readonly Dictionary<string, SlotEntry> _slotsByPortId = new(StringComparer.Ordinal);
        private readonly Dictionary<int, string> _portIdsBySlot = new();

        public int NextSlotIndex { get; set; }

        public void Add(string portId, int slotIndex, bool isInput)
        {
            _slotsByPortId[portId] = new SlotEntry(slotIndex, isInput);
            _portIdsBySlot[slotIndex] = portId;
        }

        public bool TryGetSlot(string portId, out int slotIndex)
        {
            if (_slotsByPortId.TryGetValue(portId, out var entry))
            {
                slotIndex = entry.SlotIndex;
                return true;
            }

            slotIndex = -1;
            return false;
        }

        public bool TryGetPortId(int slotIndex, out string portId)
        {
            return _portIdsBySlot.TryGetValue(slotIndex, out portId!);
        }

        private readonly record struct SlotEntry(int SlotIndex, bool IsInput);
    }
}
