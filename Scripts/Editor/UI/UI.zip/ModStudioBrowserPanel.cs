using System;
using System.Collections.Generic;
using System.Linq;
using Godot;
using STS2_Editor.Scripts.Editor.Core.Models;
using STS2_Editor.Scripts.Editor.Core.Utilities;
using static STS2_Editor.Scripts.Editor.UI.ModStudioUiFactory;

namespace STS2_Editor.Scripts.Editor.UI;

internal sealed partial class ModStudioBrowserPanel : MarginContainer
{
    private TabContainer? _kindTabs;
    private LineEdit? _searchEdit;
    private OptionButton? _scopeFilter;
    private readonly Dictionary<ModStudioEntityKind, VBoxContainer> _lists = new();
    private readonly IReadOnlyList<ModStudioEntityKind> _browserKinds = Enum
        .GetValues<ModStudioEntityKind>()
        .Where(kind => kind != ModStudioEntityKind.Monster)
        .ToList();

    public event System.Action<ModStudioEntityKind>? KindChanged;
    public event System.Action<string>? SearchChanged;
    public event System.Action<int>? ScopeChanged;
    public event System.Action<string>? ItemSelected;
    public event System.Action? CreateEntryRequested;

    public string SearchText => _searchEdit?.Text ?? string.Empty;
    public int ScopeSelected => (int)(_scopeFilter?.Selected ?? 0);

    public override void _Ready()
    {
        SizeFlagsHorizontal = SizeFlags.ExpandFill;
        SizeFlagsVertical = SizeFlags.ExpandFill;

        var root = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        root.AddThemeConstantOverride("separation", 8);
        AddChild(root);

        var header = new HBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        header.AddChild(MakeLocalizedLabel("label.entity_browser", true));
        header.AddChild(MakeLocalizedButton("button.new_entry", () => CreateEntryRequested?.Invoke()));
        root.AddChild(header);

        _searchEdit = new LineEdit { SizeFlagsHorizontal = SizeFlags.ExpandFill, PlaceholderText = L("placeholder.search_entities") };
        _searchEdit.TextChanged += text => SearchChanged?.Invoke(text);
        root.AddChild(_searchEdit);

        _scopeFilter = new OptionButton { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        _scopeFilter.AddItem(L("filter.browser_scope_all"));
        _scopeFilter.AddItem(L("filter.browser_scope_modified"));
        _scopeFilter.AddItem(L("filter.browser_scope_project_only"));
        _scopeFilter.ItemSelected += i => ScopeChanged?.Invoke((int)i);
        root.AddChild(_scopeFilter);

        _kindTabs = new TabContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        _kindTabs.TabChanged += i =>
        {
            if (i >= 0 && i < _browserKinds.Count)
                KindChanged?.Invoke(_browserKinds[(int)i]);
        };
        root.AddChild(_kindTabs);

        foreach (var kind in _browserKinds)
        {
            var p = MakeFillTab($"Tab_{kind}", out var content);
            var scroll = MakeScrollList($"Scroll_{kind}", out var inner);
            content.AddChild(scroll);
            _lists[kind] = inner;
            _kindTabs.AddChild(p);
        }
        RefreshTabs();
    }

    public void RefreshTabs()
    {
        if (_kindTabs == null) return;
        for (int i = 0; i < _browserKinds.Count; i++)
            _kindTabs.SetTabTitle(i, ModStudioLocalization.GetEntityKindDisplayName(_browserKinds[i]));
    }

    public void SetData(ModStudioEntityKind kind, IReadOnlyList<EntityBrowserItem> items, string? currentId)
    {
        if (!_lists.TryGetValue(kind, out var list)) return;
        ClearChildren(list);
        
        if (items.Count == 0)
        {
            list.AddChild(MakeListEntry(L("placeholder.no_entries_title"), L("placeholder.no_entries_title")));
            return;
        }

        foreach (var item in items)
        {
            var b = MakeListEntry(item.Title, $"{item.EntityId}\n{item.Summary}", item.EntityId == currentId);
            b.CustomMinimumSize = new Vector2(0, 72);
            b.Pressed += () => ItemSelected?.Invoke(item.EntityId);
            list.AddChild(b);
        }
    }

    public void SelectKind(ModStudioEntityKind kind)
    {
        if (_kindTabs == null)
            return;

        var index = _browserKinds
            .Select((value, i) => new { value, i })
            .Where(pair => pair.value == kind)
            .Select(pair => pair.i)
            .DefaultIfEmpty(-1)
            .First();
        if (index >= 0 && _kindTabs.CurrentTab != index)
            _kindTabs.CurrentTab = index;
    }
}
