using Godot;
using static STS2_Editor.Scripts.Editor.UI.ModStudioUiFactory;

namespace STS2_Editor.Scripts.Editor.UI;

internal sealed partial class ModStudioAssetEditor : MarginContainer
{
    public TextureRect OriginalPreview { get; private set; } = null!;
    public TextureRect CandidatePreview { get; private set; } = null!;
    public RichTextLabel CompareDetails { get; private set; } = null!;

    public event System.Action? ApplyRuntimeRequested;
    public event System.Action? ApplyProjectRequested;
    public event System.Action? ApplyManualPathRequested;
    public event System.Action? ImportExternalRequested;
    public event System.Action? ClearRequested;

    public override void _Ready()
    {
        var root = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        root.AddThemeConstantOverride("separation", 10);
        AddChild(root);

        var compareRow = new HBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        compareRow.AddThemeConstantOverride("separation", 10);
        root.AddChild(compareRow);

        compareRow.AddChild(BuildPreviewPane("label.asset_original_preview", out var original, 1f));
        compareRow.AddChild(BuildPreviewPane("label.asset_candidate_preview", out var candidate, 1f));
        OriginalPreview = original!;
        CandidatePreview = candidate!;

        CompareDetails = MakeLocalizedDetails("placeholder.asset_compare_intro", scrollActive: false, fitContent: true, minHeight: 72f);
        root.AddChild(CompareDetails);

        root.AddChild(MakeActionRow(
            ("button.apply_selected_runtime_asset", () => ApplyRuntimeRequested?.Invoke()),
            ("button.apply_selected_project_asset", () => ApplyProjectRequested?.Invoke()),
            ("button.apply_asset_path", () => ApplyManualPathRequested?.Invoke()),
            ("button.import_external_asset", () => ImportExternalRequested?.Invoke()),
            ("button.clear_asset_override", () => ClearRequested?.Invoke())));
    }

    private static Control BuildPreviewPane(string labelKey, out TextureRect? textureRect, float stretchRatio)
    {
        var panel = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill, SizeFlagsStretchRatio = stretchRatio };
        panel.AddThemeConstantOverride("separation", 6);
        panel.AddChild(MakeLocalizedLabel(labelKey));

        var previewPanel = new PanelContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        textureRect = new TextureRect
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill,
            StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered,
            ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
            CustomMinimumSize = new Vector2(0f, 480f)
        };
        previewPanel.AddChild(textureRect);
        panel.AddChild(previewPanel);
        return panel;
    }
}
