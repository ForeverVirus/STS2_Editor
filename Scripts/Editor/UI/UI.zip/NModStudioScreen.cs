using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Godot;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Nodes.CommonUi;
using MegaCrit.Sts2.Core.Nodes.Screens.MainMenu;
using STS2_Editor.Scripts.Editor.Core.Models;
using STS2_Editor.Scripts.Editor.Core.Utilities;
using STS2_Editor.Scripts.Editor.Graph;
using STS2_Editor.Scripts.Editor.Packaging;
using STS2_Editor.Scripts.Editor.Runtime;
using static STS2_Editor.Scripts.Editor.UI.ModStudioUiFactory;

namespace STS2_Editor.Scripts.Editor.UI;

public sealed partial class NModStudioScreen : NSubmenu
{
    private const string BackButtonScenePath = "res://scenes/ui/back_button.tscn";

    private bool _uiBuilt;
    private bool _isProjectMode = true;
    private bool _suppressMetadataJsonChanged;
    private bool _suppressGraphJsonChanged;
    private bool _suppressGraphInspectorChanged;
    private bool _hasPendingUiChanges;
    private string _lastAction = string.Empty;

    private ModStudioTopBar? _topBar;
    private Control? _modeHost;
    private Control? _projectPage;
    private ModStudioPackagePage? _packagePage;
    private ModStudioBrowserPanel? _browserPanel;
    private ModStudioEditorPanel? _editorPanel;
    private ModStudioDetailPanel? _detailPanel;
    private ModStudioCloseDialog? _closeDialog;
    private FileDialog? _assetImportDialog;
    private FileDialog? _packageImportDialog;

    private ModStudioEntityKind _selectedKind = ModStudioEntityKind.Character;
    private EntityBrowserItem? _selectedBrowserItem;
    private PackageSessionState? _selectedPackage;
    private EditorProject? _currentProject;
    private IReadOnlyList<EditorProjectManifest> _projects = Array.Empty<EditorProjectManifest>();
    private IReadOnlyList<PackageSessionState> _packages = Array.Empty<PackageSessionState>();
    private string? _selectedRuntimeAssetPath;
    private AssetRef? _selectedProjectAsset;
    private string? _selectedGraphNodeId;

    protected override Control? InitialFocusedControl => _topBar;
    public static IEnumerable<string> AssetPaths => new[] { BackButtonScenePath };
    public static NModStudioScreen Create() => new();

    public override void _Ready()
    {
        EnsureUiBuilt();
        base.ConnectSignals();
        HideBackButtonImmediately();
        RefreshData();
        SetMode(true);
    }

    public override void OnSubmenuOpened()
    {
        HideBackButtonImmediately();
        RefreshData();
        SetMode(_isProjectMode);
    }

    protected override void OnSubmenuShown()
    {
        base.OnSubmenuShown();
        HideBackButtonImmediately();
    }

    public override void OnSubmenuClosed()
    {
        base.OnSubmenuClosed();
        _hasPendingUiChanges = false;
        _closeDialog?.Hide();
    }

    private void EnsureUiBuilt()
    {
        if (_uiBuilt)
            return;

        _uiBuilt = true;
        SizeFlagsHorizontal = SizeFlags.ExpandFill;
        SizeFlagsVertical = SizeFlags.ExpandFill;
        SetAnchorsPreset(LayoutPreset.FullRect);
        MouseFilter = MouseFilterEnum.Stop;

        var backdrop = new PanelContainer
        {
            Name = "ModStudioBackdrop",
            AnchorRight = 1f,
            AnchorBottom = 1f,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        AddChild(backdrop);
        backdrop.AddChild(new ColorRect
        {
            AnchorRight = 1f,
            AnchorBottom = 1f,
            Color = new Color(0.04f, 0.06f, 0.08f, 0.96f),
            MouseFilter = MouseFilterEnum.Ignore
        });

        var root = new VBoxContainer
        {
            AnchorRight = 1f,
            AnchorBottom = 1f,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        root.AddThemeConstantOverride("separation", 0);
        backdrop.AddChild(root);

        _topBar = new ModStudioTopBar();
        root.AddChild(_topBar);

        _modeHost = new Control
        {
            Name = "ModeHost",
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        root.AddChild(_modeHost);

        _projectPage = BuildProjectPage();
        _packagePage = new ModStudioPackagePage();
        ConfigureOverlayControl(_projectPage);
        ConfigureOverlayControl(_packagePage);
        _modeHost.AddChild(_projectPage);
        _modeHost.AddChild(_packagePage);

        _closeDialog = new ModStudioCloseDialog();
        AddChild(_closeDialog);

        _packageImportDialog = new FileDialog
        {
            Name = "PackageImportDialog",
            Title = L("placeholder.import_package_title"),
            Access = FileDialog.AccessEnum.Filesystem,
            FileMode = FileDialog.FileModeEnum.OpenFile,
            UseNativeDialog = true
        };
        _packageImportDialog.FileSelected += OnPackageImportSelected;
        AddChild(_packageImportDialog);

        _assetImportDialog = new FileDialog
        {
            Name = "AssetImportDialog",
            Title = L("placeholder.import_asset_title"),
            Access = FileDialog.AccessEnum.Filesystem,
            FileMode = FileDialog.FileModeEnum.OpenFile,
            UseNativeDialog = true,
            Filters = new[] { "*.png,*.jpg,*.jpeg,*.webp ; Supported Images" }
        };
        _assetImportDialog.FileSelected += OnAssetImportSelected;
        AddChild(_assetImportDialog);

        AddBackButton();
        ConnectUiSignals();
    }

    private Control BuildProjectPage()
    {
        var margin = new MarginContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        margin.AddThemeConstantOverride("margin_left", 10);
        margin.AddThemeConstantOverride("margin_top", 10);
        margin.AddThemeConstantOverride("margin_right", 10);
        margin.AddThemeConstantOverride("margin_bottom", 10);

        var row = new HBoxContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        row.AddThemeConstantOverride("separation", 10);
        margin.AddChild(row);

        _browserPanel = new ModStudioBrowserPanel();
        _editorPanel = new ModStudioEditorPanel();
        _detailPanel = new ModStudioDetailPanel();

        row.AddChild(MakeColumn("BrowserColumn", 2f, _browserPanel));
        row.AddChild(MakeColumn("EditorColumn", 6f, _editorPanel));
        row.AddChild(MakeColumn("DetailsColumn", 2f, _detailPanel));

        return margin;
    }

    private void ConnectUiSignals()
    {
        if (_topBar != null)
        {
            _topBar.ModeChanged += SetMode;
            _topBar.ProjectSelected += OpenProject;
            _topBar.NewProjectRequested += CreateNewProject;
            _topBar.ExportProjectRequested += ExportCurrentProject;
            _topBar.ImportPackageRequested += ShowPackageImportDialog;
            _topBar.RefreshRequested += RefreshData;
            _topBar.CloseRequested += RequestCloseModStudio;
            _topBar.LanguageChanged += OnLanguageChanged;
        }

        if (_browserPanel != null)
        {
            _browserPanel.KindChanged += kind => SelectBrowserKind(kind, false);
            _browserPanel.SearchChanged += _ => RefreshBrowserList(true);
            _browserPanel.ScopeChanged += _ => RefreshBrowserList(false);
            _browserPanel.ItemSelected += OnBrowserItemSelected;
            _browserPanel.CreateEntryRequested += CreateNewEntryForSelectedKind;
        }

        if (_editorPanel != null)
        {
            _editorPanel.WorkspaceTabs.TabChanged += index => _detailPanel?.SyncToWorkspaceTab((int)index);
            _editorPanel.BasicEditor.CaptureRuntimeRequested += CaptureSelectedRuntimeMetadata;
            _editorPanel.BasicEditor.ApplyEventTemplateRequested += ApplyEventTemplateScaffold;
            _editorPanel.BasicEditor.SaveRequested += SaveCurrentOverride;
            _editorPanel.BasicEditor.RemoveRequested += RemoveCurrentOverride;
            _editorPanel.BasicEditor.MetadataChanged += OnMetadataJsonTextChanged;
            _editorPanel.BasicEditor.NotesEdit.TextChanged += MarkUiDirty;
            _editorPanel.AssetEditor.ApplyRuntimeRequested += ApplySelectedRuntimeCatalogAsset;
            _editorPanel.AssetEditor.ApplyProjectRequested += ApplySelectedProjectAsset;
            _editorPanel.AssetEditor.ApplyManualPathRequested += ApplyManualAssetPath;
            _editorPanel.AssetEditor.ImportExternalRequested += ShowAssetImportDialog;
            _editorPanel.AssetEditor.ClearRequested += ClearSelectedAssetBinding;
            _editorPanel.GraphEditor.CanvasView.GraphChanged += OnGraphCanvasChanged;
            _editorPanel.GraphEditor.CanvasView.SelectedNodeChanged += OnGraphCanvasSelectedNodeChanged;
        }

        if (_detailPanel != null)
        {
            _detailPanel.ApplyAssetPathRequested += ApplyManualAssetPath;
            _detailPanel.ImportExternalAssetRequested += ShowAssetImportDialog;
            _detailPanel.ClearAssetRequested += ClearSelectedAssetBinding;
            _detailPanel.SaveGraphRequested += SaveCurrentGraph;
            _detailPanel.AssetPathEdit.TextChanged += OnAssetPathTextChanged;
            _detailPanel.AssetCatalogFilterEdit.TextChanged += _ => RefreshRuntimeAssetCatalogList();
            _detailPanel.GraphJsonEdit.TextChanged += OnGraphJsonTextChanged;
            _detailPanel.GraphIdEdit.TextChanged += OnGraphIdTextChanged;
            _detailPanel.GraphToggle.Toggled += _ =>
            {
                RefreshGraphEditorPanels();
                MarkUiDirty();
            };
            _detailPanel.GraphNodeDisplayNameEdit.TextChanged += OnGraphNodeDisplayNameChanged;
            _detailPanel.GraphNodeDescriptionEdit.TextChanged += OnGraphNodeDescriptionChanged;
        }

        if (_packagePage != null)
        {
            _packagePage.ImportRequested += ShowPackageImportDialog;
            _packagePage.RefreshRequested += RefreshPackages;
            _packagePage.ToggleRequested += ToggleSelectedPackage;
            _packagePage.MoveRequested += MoveSelectedPackage;
            _packagePage.PackageSelected += OnPackageSelected;
        }

        if (_closeDialog != null)
        {
            _closeDialog.SaveAndExit += SaveAndCloseModStudio;
            _closeDialog.DiscardAndExit += DiscardAndCloseModStudio;
            _closeDialog.Cancel += CancelCloseModStudio;
        }

        ModStudioLocalization.LanguageChanged += RefreshLocalizedUi;
    }

    private void OnLanguageChanged(string language)
    {
        var requested = language == "zh"
            ? ModStudioLocalization.ChineseLanguageCode
            : ModStudioLocalization.EnglishLanguageCode;
        if (ModStudioLocalization.SetLanguage(requested))
            SetAction(LF("status.language_switched", ModStudioLocalization.T(ModStudioLocalization.IsChinese ? "language.zh" : "language.en")));
        else
            RefreshLocalizedUi();
    }

    private void RefreshLocalizedUi()
    {
        ApplyLocalizationRecursive(this);
        _browserPanel?.RefreshTabs();
        _editorPanel?.RefreshTabTitles();
        _detailPanel?.RefreshTabTitles();
        RefreshData();
    }

    private void SetMode(bool isProjectMode)
    {
        _isProjectMode = isProjectMode;
        if (_projectPage != null) _projectPage.Visible = isProjectMode;
        if (_packagePage != null) _packagePage.Visible = !isProjectMode;
        _topBar?.SetMode(isProjectMode);
        HideBackButtonImmediately();
        UpdateStateText();
    }

    private void AddBackButton()
    {
        var scene = ResourceLoader.Load<PackedScene>(BackButtonScenePath);
        if (scene == null)
        {
            Log.Warn("Mod Studio back button scene could not be loaded.");
            return;
        }
        var backButton = scene.Instantiate<NBackButton>(PackedScene.GenEditState.Disabled);
        backButton.Name = "BackButton";
        AddChild(backButton);
        HideBackButtonImmediately();
    }

    private new void HideBackButtonImmediately()
    {
        var backButton = GetNodeOrNull<Control>("BackButton");
        if (backButton != null)
            backButton.Visible = false;
    }

    private void RefreshData()
    {
        var projectId = _currentProject?.Manifest.ProjectId;
        var packageKey = _selectedPackage?.PackageKey;

        _projects = SafeGetProjects();
        ModStudioBootstrap.RuntimeRegistry.Refresh();
        _packages = SafeGetPackages();

        if (!string.IsNullOrWhiteSpace(projectId) && ModStudioBootstrap.ProjectStore.TryLoad(projectId, out var loaded) && loaded != null)
            _currentProject = loaded;
        else if (_currentProject == null && _projects.Count > 0)
            ModStudioBootstrap.ProjectStore.TryLoad(_projects[0].ProjectId, out _currentProject);
        else if (_projects.Count == 0)
            _currentProject = null;

        _selectedPackage = !string.IsNullOrWhiteSpace(packageKey)
            ? _packages.FirstOrDefault(p => p.PackageKey == packageKey)
            : _packages.FirstOrDefault();

        _topBar?.SetProjects(_projects, _currentProject?.Manifest.ProjectId);
        _packagePage?.SetPackages(_packages, _selectedPackage?.PackageKey);
        SelectBrowserKind(_selectedKind, true);
        UpdateProjectDetails();
        UpdatePackageDetails();
        SyncOverrideEditor();
        UpdateStateText();
    }

    private IReadOnlyList<EditorProjectManifest> SafeGetProjects()
    {
        try { return ModStudioBootstrap.ProjectStore.EnumerateProjectManifests(); }
        catch (Exception ex)
        {
            Log.Warn($"Failed to load Mod Studio projects: {ex.Message}");
            SetAction(LF("status.project_load_failed", ex.Message));
            return Array.Empty<EditorProjectManifest>();
        }
    }

    private IReadOnlyList<PackageSessionState> SafeGetPackages()
    {
        try { return ModStudioBootstrap.RuntimeRegistry.SessionStates.OrderBy(x => x.LoadOrder).ThenBy(x => x.PackageKey, StringComparer.Ordinal).ToList(); }
        catch (Exception ex)
        {
            Log.Warn($"Failed to load Mod Studio package sessions: {ex.Message}");
            SetAction(LF("status.package_load_failed", ex.Message));
            return Array.Empty<PackageSessionState>();
        }
    }

    private void SelectBrowserKind(ModStudioEntityKind kind, bool preserveSelectedItem)
    {
        _selectedKind = kind;
        _browserPanel?.SelectKind(kind);
        RefreshBrowserList(preserveSelectedItem);
    }

    private void RefreshBrowserList(bool preserveSelectedItem)
    {
        if (!preserveSelectedItem || _selectedBrowserItem?.Kind != _selectedKind)
            _selectedBrowserItem = null;

        var items = GetFilteredBrowserItems(_selectedKind);
        if (_selectedBrowserItem == null || !items.Any(i => i.EntityId == _selectedBrowserItem.EntityId))
            _selectedBrowserItem = items.FirstOrDefault();

        _browserPanel?.SetData(_selectedKind, items, _selectedBrowserItem?.EntityId);
        SyncOverrideEditor();
        RefreshGraphEditorPanels();
        RefreshGraphNodeInspector();
        UpdateStateText();
    }

    private List<EntityBrowserItem> GetFilteredBrowserItems(ModStudioEntityKind kind)
    {
        var filter = (_browserPanel?.SearchText ?? string.Empty).Trim();
        var scope = _browserPanel?.ScopeSelected ?? 0;

        return ModStudioBootstrap.ModelMetadataService
            .GetItems(kind, _currentProject)
            .Where(item => string.IsNullOrWhiteSpace(filter) ||
                           item.EntityId.Contains(filter, StringComparison.OrdinalIgnoreCase) ||
                           item.Title.Contains(filter, StringComparison.OrdinalIgnoreCase) ||
                           item.Summary.Contains(filter, StringComparison.OrdinalIgnoreCase))
            .Where(item => MatchesBrowserScope(scope, item))
            .ToList();
    }

    private bool MatchesBrowserScope(long scope, EntityBrowserItem item)
    {
        var envelope = GetCurrentEnvelope(item);
        return scope switch
        {
            1 => envelope != null,
            2 => item.IsProjectOnly,
            _ => true
        };
    }

    private EntityOverrideEnvelope? GetCurrentEnvelope(EntityBrowserItem item)
    {
        return _currentProject?.Overrides.FirstOrDefault(envelope =>
            envelope.EntityKind == item.Kind &&
            string.Equals(envelope.EntityId, item.EntityId, StringComparison.Ordinal));
    }

    private void OnBrowserItemSelected(string entityId)
    {
        _selectedBrowserItem = ModStudioBootstrap.ModelMetadataService
            .GetItems(_selectedKind, _currentProject)
            .FirstOrDefault(item => item.EntityId == entityId);
        RefreshBrowserList(true);
    }

    private void UpdateProjectDetails()
    {
        var detailText = _currentProject == null
            ? L("placeholder.no_workspace_project")
            : string.Join(System.Environment.NewLine,
                LF("detail.project_id", _currentProject.Manifest.ProjectId),
                LF("detail.name", _currentProject.Manifest.Name),
                LF("detail.author", _currentProject.Manifest.Author),
                LF("detail.description", _currentProject.Manifest.Description),
                LF("detail.target_game", _currentProject.Manifest.TargetGameVersion),
                LF("detail.editor_version", _currentProject.Manifest.EditorVersion),
                LF("detail.overrides", _currentProject.Overrides.Count),
                LF("detail.graphs", _currentProject.Graphs.Count),
                LF("detail.assets", _currentProject.ProjectAssets.Count),
                LF("detail.updated", _currentProject.Manifest.UpdatedAtUtc));

        if (_editorPanel != null)
            _editorPanel.ProjectDetails.Text = detailText;
        if (_detailPanel != null)
            _detailPanel.BasicProjectDetails.Text = detailText;
    }

    private void UpdatePackageDetails()
    {
        if (_packagePage == null)
            return;

        if (_selectedPackage == null)
        {
            _packagePage.PackageDetails.Text = L("placeholder.no_package_selected");
            _packagePage.ConflictDetails.Text = L("placeholder.no_package_selected");
            return;
        }

        var runtimePackage = ModStudioBootstrap.RuntimeRegistry.InstalledPackages.FirstOrDefault(x => x.PackageKey == _selectedPackage.PackageKey);
        _packagePage.PackageDetails.Text = string.Join(System.Environment.NewLine,
            LF("detail.package_key", _selectedPackage.PackageKey),
            LF("detail.package_id", _selectedPackage.PackageId),
            LF("detail.display_name", _selectedPackage.DisplayName),
            LF("detail.version", _selectedPackage.Version),
            LF("detail.checksum", _selectedPackage.Checksum),
            LF("detail.load_order", _selectedPackage.LoadOrder),
            LF("detail.enabled", BoolText(_selectedPackage.Enabled)),
            LF("detail.session_enabled", BoolText(_selectedPackage.SessionEnabled)),
            LF("detail.disabled_reason", _selectedPackage.DisabledReason),
            LF("detail.package_file", _selectedPackage.PackageFilePath),
            LF("detail.override_count", runtimePackage?.Project.Overrides.Count ?? 0),
            LF("detail.graph_count", runtimePackage?.Project.Graphs.Count ?? 0),
            LF("detail.asset_count", runtimePackage?.Project.ProjectAssets.Count ?? 0));
        _packagePage.ConflictDetails.Text = BuildPackageConflictDetails(_selectedPackage.PackageKey);
    }

    private string BuildPackageConflictDetails(string packageKey)
    {
        var conflicts = ModStudioBootstrap.RuntimeRegistry.LastResolution.Conflicts
            .Where(conflict => conflict.Participants.Any(participant => string.Equals(participant.PackageKey, packageKey, StringComparison.Ordinal)))
            .OrderBy(conflict => conflict.EntityKind)
            .ThenBy(conflict => conflict.EntityId, StringComparer.Ordinal)
            .ToList();

        if (conflicts.Count == 0)
            return L("placeholder.no_package_conflicts");

        var lines = new List<string> { LF("detail.package_conflict_count", conflicts.Count) };
        foreach (var conflict in conflicts.Take(20))
        {
            var winner = conflict.Participants.FirstOrDefault(participant => string.Equals(participant.PackageKey, conflict.WinningPackageKey, StringComparison.Ordinal));
            var participantText = string.Join(" -> ", conflict.Participants.OrderBy(participant => participant.LoadOrder).ThenBy(participant => participant.PackageKey, StringComparer.Ordinal).Select(participant => $"{participant.DisplayName}#{participant.LoadOrder}"));
            lines.Add(LF("detail.package_conflict_entry", ModStudioLocalization.GetEntityKindDisplayName(conflict.EntityKind), conflict.EntityId, winner?.DisplayName ?? conflict.WinningPackageKey, participantText));
        }
        if (conflicts.Count > 20)
            lines.Add(LF("placeholder.package_conflicts_more", conflicts.Count - 20));
        return string.Join(System.Environment.NewLine, lines);
    }

    private void SyncOverrideEditor()
    {
        if (_editorPanel == null || _detailPanel == null)
            return;

        if (_selectedBrowserItem == null)
        {
            _detailPanel.BasicObjectDetails.Text = L("placeholder.select_runtime_object");
            _editorPanel.BasicEditor.MetadataEdit.Text = string.Empty;
            _editorPanel.BasicEditor.NotesEdit.Text = string.Empty;
            _detailPanel.GraphToggle.ButtonPressed = false;
            _detailPanel.GraphIdEdit.Text = string.Empty;
            _detailPanel.GraphJsonEdit.Text = string.Empty;
            RefreshMetadataStructuredFields();
            RefreshAssetEditor();
            RefreshGraphEditorPanels();
            RefreshGraphNodeInspector();
            return;
        }

        _detailPanel.BasicObjectDetails.Text = _selectedBrowserItem.DetailText;
        var envelope = _currentProject?.Overrides.FirstOrDefault(x => x.EntityKind == _selectedBrowserItem.Kind && x.EntityId == _selectedBrowserItem.EntityId);

        _suppressMetadataJsonChanged = true;
        _suppressGraphJsonChanged = true;
        try
        {
            _editorPanel.BasicEditor.MetadataEdit.Text = JsonSerializer.Serialize(envelope?.Metadata ?? ModStudioBootstrap.ModelMetadataService.GetEditableMetadata(_selectedBrowserItem.Kind, _selectedBrowserItem.EntityId), ModStudioJson.Options);
            _editorPanel.BasicEditor.NotesEdit.Text = envelope?.Notes ?? string.Empty;
            _detailPanel.GraphToggle.ButtonPressed = envelope?.BehaviorSource == BehaviorSource.Graph;
            _detailPanel.GraphIdEdit.Text = envelope?.GraphId ?? string.Empty;
            _detailPanel.GraphJsonEdit.Text = ResolveGraphJsonText(_currentProject, envelope, _selectedBrowserItem.Kind);
        }
        finally
        {
            _suppressMetadataJsonChanged = false;
            _suppressGraphJsonChanged = false;
        }

        RefreshMetadataStructuredFields();
        RefreshAssetEditor();
        RefreshGraphEditorPanels();
        RefreshGraphNodeInspector();
    }

    private void RefreshMetadataStructuredFields()
    {
        if (_editorPanel == null)
            return;

        ClearChildren(_editorPanel.BasicEditor.MetadataFieldList);
        var list = _editorPanel.BasicEditor.MetadataFieldList;
        if (_selectedBrowserItem == null)
        {
            list.AddChild(MakeListEntry(L("placeholder.no_selection"), L("placeholder.select_runtime_object")));
            return;
        }

        Dictionary<string, string> metadata;
        try { metadata = ParseMetadata(_editorPanel.BasicEditor.MetadataEdit.Text); }
        catch { metadata = GetEffectiveMetadataForSelectedItem(); }

        if (metadata.Count == 0)
        {
            list.AddChild(MakeListEntry(L("placeholder.no_entries_title"), L("placeholder.metadata_fields_empty")));
            return;
        }

        foreach (var pair in metadata.OrderBy(pair => GetMetadataFieldPriority(pair.Key)).ThenBy(pair => pair.Key, StringComparer.OrdinalIgnoreCase))
            list.AddChild(CreateMetadataFieldEditor(pair.Key, pair.Value));
    }

    private Control CreateMetadataFieldEditor(string key, string value)
    {
        var box = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        box.AddThemeConstantOverride("separation", 4);
        box.AddChild(new Label { Text = FormatMetadataFieldLabel(key), SizeFlagsHorizontal = SizeFlags.ExpandFill });

        if (bool.TryParse(value, out var boolValue))
        {
            var toggle = new CheckButton { Text = BoolText(boolValue), ButtonPressed = boolValue, SizeFlagsHorizontal = SizeFlags.ExpandFill };
            toggle.Toggled += pressed =>
            {
                toggle.Text = BoolText(pressed);
                UpsertMetadataFieldValue(key, pressed.ToString());
            };
            box.AddChild(toggle);
            return box;
        }

        var edit = new LineEdit { Text = value, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        edit.TextChanged += text => UpsertMetadataFieldValue(key, text);
        box.AddChild(edit);
        return box;
    }

    private void UpsertMetadataFieldValue(string key, string value)
    {
        if (_editorPanel == null)
            return;

        Dictionary<string, string> metadata;
        try { metadata = ParseMetadata(_editorPanel.BasicEditor.MetadataEdit.Text); }
        catch { metadata = GetEffectiveMetadataForSelectedItem(); }

        metadata[key] = value;
        _suppressMetadataJsonChanged = true;
        try { _editorPanel.BasicEditor.MetadataEdit.Text = JsonSerializer.Serialize(metadata, ModStudioJson.Options); }
        finally { _suppressMetadataJsonChanged = false; }

        RefreshAssetEditor();
        MarkUiDirty();
    }

    private void RefreshAssetEditor()
    {
        if (_detailPanel == null || _editorPanel == null)
            return;

        if (_selectedBrowserItem == null)
        {
            _detailPanel.AssetBindingDetails.Text = L("placeholder.asset_binding_select");
            _detailPanel.AssetPathEdit.Text = string.Empty;
            _editorPanel.AssetEditor.OriginalPreview.Texture = null;
            _editorPanel.AssetEditor.CandidatePreview.Texture = null;
            _selectedRuntimeAssetPath = null;
            _selectedProjectAsset = null;
            RefreshRuntimeAssetCatalogList();
            RefreshProjectAssetLibraryList();
            RefreshAssetComparisonPreview();
            return;
        }

        if (!ModStudioBootstrap.ProjectAssetBindingService.TryGetDescriptor(_selectedBrowserItem.Kind, out var descriptor))
        {
            _detailPanel.AssetBindingDetails.Text = LF("placeholder.asset_binding_unsupported", ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind));
            _detailPanel.AssetPathEdit.Text = string.Empty;
            _selectedRuntimeAssetPath = null;
            _selectedProjectAsset = null;
            RefreshRuntimeAssetCatalogList();
            RefreshProjectAssetLibraryList();
            RefreshAssetComparisonPreview();
            return;
        }

        var metadata = GetEffectiveMetadataForSelectedItem();
        var currentValue = metadata.TryGetValue(descriptor.MetadataKey, out var rawValue) ? rawValue : string.Empty;
        var runtimePath = ModStudioBootstrap.ProjectAssetBindingService.GetRuntimeAssetPath(_selectedBrowserItem.Kind, _selectedBrowserItem.EntityId) ?? string.Empty;
        var envelope = _currentProject?.Overrides.FirstOrDefault(item => item.EntityKind == _selectedBrowserItem.Kind && item.EntityId == _selectedBrowserItem.EntityId);
        var resolvedPath = ModStudioBootstrap.ProjectAssetBindingService.ResolveDisplayPath(_currentProject, envelope, _selectedBrowserItem.Kind, metadata);
        var boundAssetCount = envelope?.Assets.Count(asset => string.Equals(asset.LogicalRole, descriptor.LogicalRole, StringComparison.Ordinal)) ?? 0;

        _detailPanel.AssetBindingDetails.Text = string.Join(System.Environment.NewLine,
            LF("asset.detail.role", L(descriptor.DisplayNameKey)),
            LF("asset.detail.metadata_key", descriptor.MetadataKey),
            LF("asset.detail.runtime_default", runtimePath),
            LF("asset.detail.current_binding", string.IsNullOrWhiteSpace(currentValue) ? L("misc.none") : currentValue),
            LF("asset.detail.resolved_path", string.IsNullOrWhiteSpace(resolvedPath) ? L("misc.none") : resolvedPath),
            LF("asset.detail.tracked_assets", boundAssetCount));
        _detailPanel.AssetPathEdit.Text = currentValue;
        _selectedRuntimeAssetPath = string.IsNullOrWhiteSpace(runtimePath) ? null : runtimePath;
        _selectedProjectAsset = envelope?.Assets.FirstOrDefault(asset => string.Equals(asset.LogicalRole, descriptor.LogicalRole, StringComparison.Ordinal));
        RefreshRuntimeAssetCatalogList();
        RefreshProjectAssetLibraryList();
        RefreshAssetComparisonPreview();
    }

    private void RefreshAssetComparisonPreview()
    {
        if (_detailPanel == null || _editorPanel == null)
            return;

        var originalPath = ResolveCurrentAssetResolvedPath();
        var candidatePath = ResolveAssetCandidatePreviewPath();
        _editorPanel.AssetEditor.OriginalPreview.Texture = ModStudioPreviewHelper.LoadPreviewTexture(originalPath);
        _editorPanel.AssetEditor.CandidatePreview.Texture = ModStudioPreviewHelper.LoadPreviewTexture(candidatePath);
        _editorPanel.AssetEditor.CompareDetails.Text = string.Join(System.Environment.NewLine,
            LF("detail.original_path", string.IsNullOrWhiteSpace(originalPath) ? L("misc.none") : originalPath),
            LF("detail.candidate_path", string.IsNullOrWhiteSpace(candidatePath) ? L("misc.none") : candidatePath),
            string.IsNullOrWhiteSpace(candidatePath) ? L("placeholder.asset_compare_select_candidate") : L("placeholder.asset_compare_ready"));
    }

    private string? ResolveCurrentAssetResolvedPath()
    {
        if (_selectedBrowserItem == null)
            return null;
        if (!ModStudioBootstrap.ProjectAssetBindingService.TryGetDescriptor(_selectedBrowserItem.Kind, out _))
            return null;
        var metadata = GetEffectiveMetadataForSelectedItem();
        var envelope = _currentProject?.Overrides.FirstOrDefault(item => item.EntityKind == _selectedBrowserItem.Kind && item.EntityId == _selectedBrowserItem.EntityId);
        return ModStudioBootstrap.ProjectAssetBindingService.ResolveDisplayPath(_currentProject, envelope, _selectedBrowserItem.Kind, metadata);
    }

    private string? ResolveAssetCandidatePreviewPath()
    {
        if (_selectedProjectAsset != null)
            return _selectedProjectAsset.ManagedPath;
        if (!string.IsNullOrWhiteSpace(_selectedRuntimeAssetPath))
            return _selectedRuntimeAssetPath;
        var path = (_detailPanel?.AssetPathEdit.Text ?? string.Empty).Trim();
        return string.IsNullOrWhiteSpace(path) ? null : path;
    }

    private void RefreshRuntimeAssetCatalogList()
    {
        if (_detailPanel == null)
            return;
        ClearChildren(_detailPanel.RuntimeAssetList);

        if (_selectedBrowserItem == null)
        {
            _detailPanel.RuntimeAssetList.AddChild(MakeListEntry(L("placeholder.no_selection"), L("placeholder.asset_binding_select")));
            UpdateRuntimeAssetSelection(null);
            return;
        }

        if (!ModStudioBootstrap.ProjectAssetBindingService.TryGetDescriptor(_selectedBrowserItem.Kind, out var descriptor))
        {
            _detailPanel.RuntimeAssetList.AddChild(MakeListEntry(L("placeholder.no_entries_title"), LF("placeholder.asset_binding_unsupported", ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind))));
            UpdateRuntimeAssetSelection(null);
            return;
        }

        if (!descriptor.SupportsRuntimeCatalog)
        {
            _detailPanel.RuntimeAssetList.AddChild(MakeListEntry(L("placeholder.asset_catalog_unavailable"), L("placeholder.asset_catalog_external_only")));
            UpdateRuntimeAssetSelection(null);
            return;
        }

        var filter = (_detailPanel.AssetCatalogFilterEdit.Text ?? string.Empty).Trim();
        var candidates = ModStudioBootstrap.ProjectAssetBindingService.GetRuntimeAssetCandidates(_selectedBrowserItem.Kind)
            .Where(path => string.IsNullOrWhiteSpace(filter) || path.Contains(filter, StringComparison.OrdinalIgnoreCase))
            .ToList();
        if (candidates.Count == 0)
        {
            _detailPanel.RuntimeAssetList.AddChild(MakeListEntry(L("placeholder.no_entries_title"), L("placeholder.asset_catalog_no_match")));
            UpdateRuntimeAssetSelection(null);
            return;
        }

        var preferred = candidates.FirstOrDefault(path => string.Equals(path, _detailPanel.AssetPathEdit.Text?.Trim(), StringComparison.OrdinalIgnoreCase))
            ?? candidates.FirstOrDefault(path => string.Equals(path, _selectedRuntimeAssetPath, StringComparison.OrdinalIgnoreCase))
            ?? candidates[0];

        foreach (var path in candidates.Take(200))
        {
            var captured = path;
            var button = MakeListEntry(path, string.Equals(path, preferred, StringComparison.OrdinalIgnoreCase) ? L("asset.catalog_selected") : L("asset.catalog_click_to_preview"), string.Equals(path, preferred, StringComparison.OrdinalIgnoreCase));
            button.CustomMinimumSize = new Vector2(0f, 72f);
            button.Pressed += () =>
            {
                _selectedRuntimeAssetPath = captured;
                RefreshRuntimeAssetCatalogList();
            };
            _detailPanel.RuntimeAssetList.AddChild(button);
        }

        UpdateRuntimeAssetSelection(preferred);
    }

    private void RefreshProjectAssetLibraryList()
    {
        if (_detailPanel == null)
            return;
        ClearChildren(_detailPanel.ProjectAssetList);

        if (_currentProject == null || _selectedBrowserItem == null)
        {
            _detailPanel.ProjectAssetList.AddChild(MakeListEntry(L("placeholder.no_selection"), L("placeholder.asset_binding_select")));
            UpdateProjectAssetSelection(null);
            return;
        }

        if (!ModStudioBootstrap.ProjectAssetBindingService.TryGetDescriptor(_selectedBrowserItem.Kind, out var descriptor))
        {
            _detailPanel.ProjectAssetList.AddChild(MakeListEntry(L("placeholder.no_entries_title"), LF("placeholder.asset_binding_unsupported", ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind))));
            UpdateProjectAssetSelection(null);
            return;
        }

        var assets = _currentProject.ProjectAssets
            .Where(asset => string.Equals(asset.LogicalRole, descriptor.LogicalRole, StringComparison.Ordinal))
            .OrderBy(asset => asset.FileName, StringComparer.OrdinalIgnoreCase)
            .ThenBy(asset => asset.ManagedPath, StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (assets.Count == 0)
        {
            _detailPanel.ProjectAssetList.AddChild(MakeListEntry(L("placeholder.no_entries_title"), L("placeholder.asset_project_library_empty")));
            UpdateProjectAssetSelection(null);
            return;
        }

        var preferred = assets.FirstOrDefault(asset => string.Equals(asset.ManagedPath, _detailPanel.AssetPathEdit.Text?.Trim(), StringComparison.OrdinalIgnoreCase))
            ?? assets.FirstOrDefault(asset => string.Equals(asset.Id, _selectedProjectAsset?.Id, StringComparison.Ordinal))
            ?? assets[0];

        foreach (var asset in assets)
        {
            var captured = asset;
            var subtitle = string.Join(System.Environment.NewLine, asset.FileName, asset.SourceType, asset.ManagedPath);
            var button = MakeListEntry(string.IsNullOrWhiteSpace(asset.FileName) ? asset.Id : asset.FileName, subtitle, string.Equals(asset.Id, preferred.Id, StringComparison.Ordinal));
            button.CustomMinimumSize = new Vector2(0f, 88f);
            button.Pressed += () =>
            {
                _selectedProjectAsset = captured;
                RefreshProjectAssetLibraryList();
            };
            _detailPanel.ProjectAssetList.AddChild(button);
        }

        UpdateProjectAssetSelection(preferred);
    }

    private void UpdateRuntimeAssetSelection(string? path)
    {
        if (_detailPanel == null)
            return;
        _selectedRuntimeAssetPath = path;
        _detailPanel.RuntimeAssetDetails.Text = string.IsNullOrWhiteSpace(path)
            ? L("placeholder.asset_runtime_select")
            : string.Join(System.Environment.NewLine,
                LF("detail.path", path),
                LF("detail.file_name", Path.GetFileName(path)),
                LF("detail.preview_state", ModStudioPreviewHelper.LoadPreviewTexture(path) != null ? L("bool.true") : L("bool.false")));
        RefreshAssetComparisonPreview();
    }

    private void UpdateProjectAssetSelection(AssetRef? asset)
    {
        if (_detailPanel == null)
            return;
        _selectedProjectAsset = asset;
        _detailPanel.ProjectAssetDetails.Text = asset == null
            ? L("placeholder.asset_project_select")
            : string.Join(System.Environment.NewLine,
                LF("detail.file_name", asset.FileName),
                LF("detail.source_path", asset.SourcePath),
                LF("detail.managed_path", asset.ManagedPath),
                LF("detail.logical_role", asset.LogicalRole));
        RefreshAssetComparisonPreview();
    }

    private void OnAssetPathTextChanged(string _)
    {
        RefreshAssetComparisonPreview();
        MarkUiDirty();
    }

    private void ApplySelectedRuntimeCatalogAsset()
    {
        if (string.IsNullOrWhiteSpace(_selectedRuntimeAssetPath))
        {
            SetAction(L("status.select_runtime_asset_from_catalog"));
            return;
        }
        if (_detailPanel != null)
            _detailPanel.AssetPathEdit.Text = _selectedRuntimeAssetPath;
        ApplyManualAssetPath();
    }

    private void ApplySelectedProjectAsset()
    {
        if (_currentProject == null)
        {
            SetAction(L("status.select_project_before_asset"));
            return;
        }
        if (_selectedBrowserItem == null)
        {
            SetAction(L("status.select_object_before_asset"));
            return;
        }
        if (_selectedProjectAsset == null)
        {
            SetAction(L("status.select_project_asset_from_library"));
            return;
        }
        try
        {
            var result = ModStudioBootstrap.ProjectAssetBindingService.BindProjectAsset(_currentProject, _selectedBrowserItem.Kind, _selectedBrowserItem.EntityId, _selectedProjectAsset.Id);
            PersistProjectAfterAssetChange(result);
            SetAction(LF("status.applied_project_asset", _selectedProjectAsset.FileName, _selectedBrowserItem.EntityId));
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to apply project asset: {ex.Message}");
            SetAction(LF("status.apply_project_asset_failed", ex.Message));
        }
    }

    private void ApplyManualAssetPath()
    {
        if (!TryGetSelectedAssetContext(out _, out _))
            return;
        var rawPath = (_detailPanel?.AssetPathEdit.Text ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(rawPath))
        {
            SetAction(L("status.asset_path_required"));
            return;
        }
        BindAssetPath(rawPath, treatRootedAsExternalImport: true, LF("status.bound_manual_asset", _selectedBrowserItem!.EntityId));
    }

    private void ShowAssetImportDialog()
    {
        if (_assetImportDialog == null)
        {
            SetAction(L("status.asset_dialog_unavailable"));
            return;
        }
        if (!TryGetSelectedAssetContext(out _, out _))
            return;
        _assetImportDialog.PopupCenteredRatio(0.75f);
    }

    private void OnAssetImportSelected(string sourcePath)
    {
        if (!TryGetSelectedAssetContext(out _, out _))
            return;
        try
        {
            var result = ModStudioBootstrap.ProjectAssetBindingService.ImportExternalAsset(_currentProject!, _selectedBrowserItem!.Kind, _selectedBrowserItem.EntityId, sourcePath);
            PersistProjectAfterAssetChange(result);
            SetAction(LF("status.imported_external_asset", Path.GetFileName(sourcePath), _selectedBrowserItem.EntityId));
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to import external asset: {ex.Message}");
            SetAction(LF("status.import_external_asset_failed", ex.Message));
        }
    }

    private void ClearSelectedAssetBinding()
    {
        if (!TryGetSelectedAssetContext(out _, out _))
            return;
        try
        {
            var result = ModStudioBootstrap.ProjectAssetBindingService.ClearAssetBinding(_currentProject!, _selectedBrowserItem!.Kind, _selectedBrowserItem.EntityId);
            PersistProjectAfterAssetChange(result);
            SetAction(LF("status.cleared_asset_binding", _selectedBrowserItem.EntityId));
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to clear asset binding: {ex.Message}");
            SetAction(LF("status.clear_asset_binding_failed", ex.Message));
        }
    }

    private bool TryGetSelectedAssetContext(out AssetBindingDescriptor descriptor, out EntityOverrideEnvelope? envelope)
    {
        descriptor = new AssetBindingDescriptor();
        envelope = null;
        if (_currentProject == null)
        {
            SetAction(L("status.select_project_before_asset"));
            return false;
        }
        if (_selectedBrowserItem == null)
        {
            SetAction(L("status.select_object_before_asset"));
            return false;
        }
        if (!ModStudioBootstrap.ProjectAssetBindingService.TryGetDescriptor(_selectedBrowserItem.Kind, out descriptor))
        {
            SetAction(LF("status.asset_binding_unsupported", ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind)));
            return false;
        }
        envelope = _currentProject.Overrides.FirstOrDefault(item => item.EntityKind == _selectedBrowserItem.Kind && item.EntityId == _selectedBrowserItem.EntityId);
        return true;
    }

    private void BindAssetPath(string rawPath, bool treatRootedAsExternalImport, string successMessage)
    {
        try
        {
            AssetBindingResult result;
            if (treatRootedAsExternalImport && Path.IsPathRooted(rawPath) && File.Exists(rawPath))
                result = ModStudioBootstrap.ProjectAssetBindingService.ImportExternalAsset(_currentProject!, _selectedBrowserItem!.Kind, _selectedBrowserItem.EntityId, rawPath);
            else
                result = ModStudioBootstrap.ProjectAssetBindingService.BindRuntimeAsset(_currentProject!, _selectedBrowserItem!.Kind, _selectedBrowserItem.EntityId, rawPath);
            PersistProjectAfterAssetChange(result);
            SetAction(successMessage);
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to bind asset path '{rawPath}': {ex.Message}");
            SetAction(LF("status.bind_asset_failed", ex.Message));
        }
    }

    private Dictionary<string, string> GetEffectiveMetadataForSelectedItem()
    {
        if (_selectedBrowserItem == null)
            return new Dictionary<string, string>(StringComparer.Ordinal);
        if (_editorPanel != null && !string.IsNullOrWhiteSpace(_editorPanel.BasicEditor.MetadataEdit.Text))
        {
            try { return ParseMetadata(_editorPanel.BasicEditor.MetadataEdit.Text); }
            catch { }
        }
        return new Dictionary<string, string>(ModStudioBootstrap.ModelMetadataService.GetEditableMetadata(_selectedBrowserItem.Kind, _selectedBrowserItem.EntityId), StringComparer.Ordinal);
    }

    private void PersistProjectAfterAssetChange(AssetBindingResult result)
    {
        if (_currentProject == null)
            return;
        ModStudioBootstrap.ProjectStore.Save(_currentProject);
        _projects = SafeGetProjects();
        _topBar?.SetProjects(_projects, _currentProject.Manifest.ProjectId);
        UpdateProjectDetails();
        SyncOverrideEditor();
        if (_detailPanel != null)
            _detailPanel.AssetPathEdit.Text = result.MetadataValue;
        ClearUiDirty();
    }

    private void ConnectGraphEvents()
    {
    }

    private void RefreshGraphEditorPanels()
    {
        RefreshGraphTemplatePanel();
        RefreshGraphCatalogPanel();
        RefreshGraphValidationPanel();
        RefreshGraphCanvas();
        RefreshGraphNodeInspector();
    }

    private void RefreshGraphTemplatePanel()
    {
        if (_detailPanel == null)
            return;
        ClearChildren(_detailPanel.GraphTemplateList);
        if (_selectedBrowserItem == null)
        {
            _detailPanel.GraphTemplateList.AddChild(MakeListEntry(L("placeholder.no_selection"), L("placeholder.graph_presets_select")));
            return;
        }
        _detailPanel.GraphTemplateList.AddChild(MakeListEntry(L("placeholder.default_scaffold"), L("placeholder.default_scaffold_hint")));
        var scaffoldButton = MakeLocalizedButton("button.apply_default_scaffold", () => ApplyGraphTemplate(null));
        scaffoldButton.CustomMinimumSize = new Vector2(0f, 60f);
        _detailPanel.GraphTemplateList.AddChild(scaffoldButton);
        var presets = ModStudioGraphUiHelpers.GetPresets(_selectedBrowserItem.Kind);
        if (presets.Count == 0)
        {
            _detailPanel.GraphTemplateList.AddChild(MakeListEntry(L("placeholder.no_specialized_presets"), L("placeholder.no_specialized_presets_hint")));
            return;
        }
        foreach (var preset in presets)
        {
            var captured = preset;
            var button = MakeButton(captured.Name, () => ApplyGraphTemplate(captured));
            button.Text = $"{captured.Name}\n{captured.Description}";
            button.CustomMinimumSize = new Vector2(0f, 72f);
            _detailPanel.GraphTemplateList.AddChild(button);
        }
    }

    private void RefreshGraphCatalogPanel()
    {
        if (_detailPanel == null)
            return;
        _detailPanel.GraphCatalogDetails.Text = _selectedBrowserItem == null
            ? L("placeholder.node_catalog_select")
            : ModStudioGraphUiHelpers.BuildNodeCatalogText(ModStudioBootstrap.GraphRegistry, _selectedBrowserItem.Kind);
    }

    private void RefreshGraphValidationPanel()
    {
        if (_detailPanel == null)
            return;
        if (_selectedBrowserItem == null)
        {
            _detailPanel.GraphValidationDetails.Text = L("placeholder.graph_validation_select");
            return;
        }
        if (_detailPanel.GraphToggle.ButtonPressed != true)
        {
            _detailPanel.GraphValidationDetails.Text = L("placeholder.graph_disabled");
            return;
        }
        if (!TryParseGraphFromEditor(out var graph, out var validation, out var parseError))
        {
            _detailPanel.GraphValidationDetails.Text = ModStudioGraphUiHelpers.BuildValidationText(graph, validation, parseError);
            return;
        }
        _detailPanel.GraphValidationDetails.Text = ModStudioGraphUiHelpers.BuildValidationText(graph, validation);
    }

    private void RefreshGraphCanvas()
    {
        if (_editorPanel == null || _detailPanel == null)
            return;
        if (_selectedBrowserItem == null || _detailPanel.GraphToggle.ButtonPressed != true)
        {
            _editorPanel.GraphEditor.CanvasView.ClearBinding();
            return;
        }
        if (!TryParseGraphFromEditor(out var graph, out _, out _) || graph == null)
        {
            _editorPanel.GraphEditor.CanvasView.ClearBinding();
            return;
        }
        _editorPanel.GraphEditor.CanvasView.BindGraph(graph, ModStudioBootstrap.GraphRegistry);
    }

    private void OnGraphJsonTextChanged()
    {
        if (_suppressGraphJsonChanged)
            return;
        RefreshGraphValidationPanel();
        RefreshGraphCanvas();
        RefreshGraphNodeInspector();
        MarkUiDirty();
    }

    private void OnGraphIdTextChanged(string _)
    {
        RefreshGraphValidationPanel();
        RefreshGraphCanvas();
        RefreshGraphNodeInspector();
        MarkUiDirty();
        UpdateStateText();
    }

    private void OnGraphCanvasChanged(BehaviorGraphDefinition graph)
    {
        if (_detailPanel == null)
            return;
        _suppressGraphJsonChanged = true;
        try { _detailPanel.GraphJsonEdit.Text = JsonSerializer.Serialize(graph, ModStudioJson.Options); }
        finally { _suppressGraphJsonChanged = false; }
        RefreshGraphValidationPanel();
        RefreshGraphNodeInspector();
        MarkUiDirty();
    }

    private void OnGraphCanvasSelectedNodeChanged(string? nodeId)
    {
        _selectedGraphNodeId = nodeId;
        RefreshGraphValidationPanel();
        RefreshGraphNodeInspector();
    }

    private bool TryParseGraphFromEditor(out BehaviorGraphDefinition? graph, out BehaviorGraphValidationResult? validation, out string? parseError)
    {
        graph = null;
        validation = null;
        parseError = null;
        if (_detailPanel?.GraphToggle.ButtonPressed != true)
            return false;
        var rawJson = _detailPanel.GraphJsonEdit.Text?.Trim();
        if (string.IsNullOrWhiteSpace(rawJson))
        {
            parseError = L("graph.validation.empty");
            return false;
        }
        try { graph = JsonSerializer.Deserialize<BehaviorGraphDefinition>(rawJson, ModStudioJson.Options); }
        catch (Exception ex) { parseError = ex.Message; return false; }
        if (graph == null)
        {
            parseError = L("graph.validation.deserialize_failed");
            return false;
        }
        graph.EntityKind ??= _selectedBrowserItem?.Kind;
        validation = ModStudioBootstrap.GraphRegistry.Validate(graph);
        return true;
    }

    private void ApplyGraphTemplate(GraphTemplatePreset? preset)
    {
        if (_currentProject == null)
        {
            SetAction(L("status.select_project_before_template"));
            return;
        }
        if (_selectedBrowserItem == null || _detailPanel == null)
        {
            SetAction(L("status.select_object_before_template"));
            return;
        }
        try
        {
            var graphId = (_detailPanel.GraphIdEdit.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(graphId))
            {
                graphId = BuildDefaultGraphId(_selectedBrowserItem.Kind, _selectedBrowserItem.EntityId);
                _detailPanel.GraphIdEdit.Text = graphId;
            }
            var graph = preset == null
                ? ModStudioGraphUiHelpers.CreateScaffoldGraph(_selectedBrowserItem.Kind, graphId, _selectedBrowserItem.EntityId)
                : ModStudioGraphUiHelpers.CreatePresetGraph(_selectedBrowserItem.Kind, graphId, _selectedBrowserItem.EntityId, preset);
            _detailPanel.GraphToggle.ButtonPressed = true;
            _detailPanel.GraphJsonEdit.Text = JsonSerializer.Serialize(graph, ModStudioJson.Options);

            var envelope = _currentProject.Overrides.FirstOrDefault(x => x.EntityKind == _selectedBrowserItem.Kind && x.EntityId == _selectedBrowserItem.EntityId);
            if (envelope == null)
            {
                envelope = new EntityOverrideEnvelope
                {
                    EntityKind = _selectedBrowserItem.Kind,
                    EntityId = _selectedBrowserItem.EntityId,
                    Metadata = new Dictionary<string, string>(ModStudioBootstrap.ModelMetadataService.GetEditableMetadata(_selectedBrowserItem.Kind, _selectedBrowserItem.EntityId), StringComparer.Ordinal)
                };
                _currentProject.Overrides.Add(envelope);
            }
            envelope.BehaviorSource = BehaviorSource.Graph;
            envelope.GraphId = graphId;
            _currentProject.Graphs[graphId] = graph;
            ModStudioBootstrap.ProjectStore.Save(_currentProject);
            _projects = SafeGetProjects();
            _topBar?.SetProjects(_projects, _currentProject.Manifest.ProjectId);
            UpdateProjectDetails();
            RefreshGraphEditorPanels();
            ClearUiDirty();
            SetAction(preset == null
                ? LF("status.applied_scaffold", ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind), _selectedBrowserItem.EntityId)
                : LF("status.applied_template", preset.Name, ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind), _selectedBrowserItem.EntityId));
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to apply graph template: {ex.Message}");
            SetAction(LF("status.apply_template_failed", ex.Message));
        }
    }

    private void RefreshGraphNodeInspector()
    {
        if (_detailPanel == null)
            return;
        if (!TryGetSelectedGraphNode(out var graph, out var node, out var descriptor))
        {
            _detailPanel.GraphNodeTypeLabel.Text = L("placeholder.graph_node_type");
            _detailPanel.GraphNodeIdLabel.Text = L("placeholder.graph_node_id");
            _suppressGraphInspectorChanged = true;
            _detailPanel.GraphNodeDisplayNameEdit.Editable = false;
            _detailPanel.GraphNodeDisplayNameEdit.Text = string.Empty;
            _detailPanel.GraphNodeDescriptionEdit.Editable = false;
            _detailPanel.GraphNodeDescriptionEdit.Text = string.Empty;
            _suppressGraphInspectorChanged = false;
            ClearChildren(_detailPanel.GraphNodePropertyList);
            _detailPanel.GraphNodePropertyList.AddChild(MakeListEntry(L("placeholder.no_selection"), L("placeholder.graph_node_select")));
            return;
        }
        _detailPanel.GraphNodeTypeLabel.Text = LF("detail.node_type", string.IsNullOrWhiteSpace(descriptor?.DisplayName) ? node.NodeType : descriptor.DisplayName);
        _detailPanel.GraphNodeIdLabel.Text = LF("detail.node_id", node.NodeId);
        _suppressGraphInspectorChanged = true;
        _detailPanel.GraphNodeDisplayNameEdit.Editable = true;
        _detailPanel.GraphNodeDescriptionEdit.Editable = true;
        _detailPanel.GraphNodeDisplayNameEdit.Text = node.DisplayName;
        _detailPanel.GraphNodeDescriptionEdit.Text = node.Description;
        _suppressGraphInspectorChanged = false;
        ClearChildren(_detailPanel.GraphNodePropertyList);
        var propertyKeys = new HashSet<string>(node.Properties.Keys, StringComparer.Ordinal);
        if (descriptor != null)
            foreach (var key in descriptor.DefaultProperties.Keys) propertyKeys.Add(key);
        if (propertyKeys.Count == 0)
        {
            _detailPanel.GraphNodePropertyList.AddChild(MakeListEntry(L("placeholder.no_entries_title"), L("placeholder.graph_node_properties_empty")));
            return;
        }
        foreach (var key in propertyKeys.OrderBy(value => value, StringComparer.OrdinalIgnoreCase))
        {
            node.Properties.TryGetValue(key, out var currentValue);
            var defaultValue = descriptor != null && descriptor.DefaultProperties.TryGetValue(key, out var descriptorDefaultValue) ? descriptorDefaultValue : string.Empty;
            _detailPanel.GraphNodePropertyList.AddChild(BuildGraphPropertyEditor(graph, node, key, currentValue ?? defaultValue));
        }
    }

    private Control BuildGraphPropertyEditor(BehaviorGraphDefinition graph, BehaviorGraphNodeDefinition node, string key, string value)
    {
        var box = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        box.AddThemeConstantOverride("separation", 4);
        box.AddChild(new Label { Text = key, SizeFlagsHorizontal = SizeFlags.ExpandFill });
        var edit = new LineEdit { Text = value, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        edit.TextChanged += text =>
        {
            node.Properties[key] = text;
            CommitGraphMutation(graph);
        };
        box.AddChild(edit);
        return box;
    }

    private bool TryGetSelectedGraphNode(out BehaviorGraphDefinition graph, out BehaviorGraphNodeDefinition node, out BehaviorGraphNodeDefinitionDescriptor? descriptor)
    {
        graph = null!;
        node = null!;
        descriptor = null;
        if (_editorPanel?.GraphEditor.CanvasView.BoundGraph == null || string.IsNullOrWhiteSpace(_selectedGraphNodeId))
            return false;
        graph = _editorPanel.GraphEditor.CanvasView.BoundGraph;
        node = graph.Nodes.FirstOrDefault(candidate => string.Equals(candidate.NodeId, _selectedGraphNodeId, StringComparison.Ordinal))!;
        if (node == null)
            return false;
        var nodeType = node.NodeType;
        descriptor = ModStudioBootstrap.GraphRegistry.Definitions.FirstOrDefault(candidate => string.Equals(candidate.NodeType, nodeType, StringComparison.Ordinal));
        return true;
    }

    private void OnGraphNodeDisplayNameChanged(string text)
    {
        if (_suppressGraphInspectorChanged)
            return;
        if (!TryGetSelectedGraphNode(out var graph, out var node, out _))
            return;
        node.DisplayName = text;
        CommitGraphMutation(graph);
    }

    private void OnGraphNodeDescriptionChanged()
    {
        if (_suppressGraphInspectorChanged || _detailPanel == null)
            return;
        if (!TryGetSelectedGraphNode(out var graph, out var node, out _))
            return;
        node.Description = _detailPanel.GraphNodeDescriptionEdit.Text ?? string.Empty;
        CommitGraphMutation(graph);
    }

    private void CommitGraphMutation(BehaviorGraphDefinition graph)
    {
        if (_detailPanel == null || _editorPanel == null)
            return;
        _suppressGraphJsonChanged = true;
        try { _detailPanel.GraphJsonEdit.Text = JsonSerializer.Serialize(graph, ModStudioJson.Options); }
        finally { _suppressGraphJsonChanged = false; }
        _editorPanel.GraphEditor.CanvasView.RebuildCanvas();
        RefreshGraphValidationPanel();
        RefreshGraphNodeInspector();
        MarkUiDirty();
    }

    private void SaveCurrentGraph()
    {
        if (_currentProject == null)
        {
            SetAction(L("status.select_project_before_save_graph"));
            return;
        }
        if (_selectedBrowserItem == null)
        {
            SetAction(L("status.select_object_before_save_graph"));
            return;
        }
        try
        {
            PersistGraphJsonIfPresent(updateActionOnSuccess: true);
            ModStudioBootstrap.ProjectStore.Save(_currentProject);
            UpdateProjectDetails();
            SyncOverrideEditor();
            ClearUiDirty();
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to save graph: {ex.Message}");
            SetAction(LF("status.save_graph_failed", ex.Message));
        }
    }

    private void PersistGraphJsonIfPresent(bool updateActionOnSuccess)
    {
        if (_currentProject == null || _selectedBrowserItem == null || _detailPanel == null || _editorPanel == null)
            return;
        if (!_detailPanel.GraphToggle.ButtonPressed)
            return;
        var graphId = (_detailPanel.GraphIdEdit.Text ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(graphId))
        {
            graphId = BuildDefaultGraphId(_selectedBrowserItem.Kind, _selectedBrowserItem.EntityId);
            _detailPanel.GraphIdEdit.Text = graphId;
        }
        EnsureGraphExists(_currentProject, graphId, _selectedBrowserItem.Kind, _selectedBrowserItem.EntityId);
        if (string.IsNullOrWhiteSpace(_detailPanel.GraphJsonEdit.Text))
        {
            _detailPanel.GraphJsonEdit.Text = _currentProject.Graphs.TryGetValue(graphId, out var existingGraph)
                ? JsonSerializer.Serialize(existingGraph, ModStudioJson.Options)
                : string.Empty;
        }
        _editorPanel.GraphEditor.CanvasView.TryExportLayout();
        BehaviorGraphDefinition? graph;
        BehaviorGraphValidationResult? validation;
        string? parseError;
        if (_editorPanel.GraphEditor.CanvasView.BoundGraph != null && string.Equals(_editorPanel.GraphEditor.CanvasView.BoundGraph.GraphId, graphId, StringComparison.Ordinal))
        {
            graph = _editorPanel.GraphEditor.CanvasView.BoundGraph;
            validation = ModStudioBootstrap.GraphRegistry.Validate(graph);
            parseError = null;
        }
        else if (!TryParseGraphFromEditor(out graph, out validation, out parseError))
        {
            throw new InvalidOperationException(parseError ?? L("graph.validation.validate_failed"));
        }
        if (validation != null && !validation.IsValid)
            throw new InvalidOperationException(string.Join(" | ", validation.Errors));
        if (graph == null)
            throw new InvalidOperationException(L("graph.validation.deserialize_failed"));
        graph.GraphId = graphId;
        graph.EntityKind ??= _selectedBrowserItem.Kind;
        _currentProject.Graphs[graphId] = graph;
        _detailPanel.GraphJsonEdit.Text = JsonSerializer.Serialize(graph, ModStudioJson.Options);
        if (updateActionOnSuccess)
            SetAction(LF("status.saved_graph", graphId));
    }

    private void SaveCurrentOverride()
    {
        if (_currentProject == null)
        {
            SetAction(L("status.select_project_before_override"));
            return;
        }
        if (_selectedBrowserItem == null || _editorPanel == null || _detailPanel == null)
        {
            SetAction(L("status.select_object_before_override"));
            return;
        }
        try
        {
            var metadata = ParseMetadata(_editorPanel.BasicEditor.MetadataEdit.Text ?? string.Empty);
            var graphId = (_detailPanel.GraphIdEdit.Text ?? string.Empty).Trim();
            var useGraph = _detailPanel.GraphToggle.ButtonPressed;
            if (useGraph && string.IsNullOrWhiteSpace(graphId))
            {
                graphId = BuildDefaultGraphId(_selectedBrowserItem.Kind, _selectedBrowserItem.EntityId);
                _detailPanel.GraphIdEdit.Text = graphId;
            }
            var envelope = _currentProject.Overrides.FirstOrDefault(x => x.EntityKind == _selectedBrowserItem.Kind && x.EntityId == _selectedBrowserItem.EntityId);
            if (envelope == null)
            {
                envelope = new EntityOverrideEnvelope { EntityKind = _selectedBrowserItem.Kind, EntityId = _selectedBrowserItem.EntityId };
                _currentProject.Overrides.Add(envelope);
            }
            envelope.BehaviorSource = useGraph ? BehaviorSource.Graph : BehaviorSource.Native;
            envelope.GraphId = string.IsNullOrWhiteSpace(graphId) ? null : graphId;
            envelope.Metadata = metadata;
            envelope.Notes = string.IsNullOrWhiteSpace(_editorPanel.BasicEditor.NotesEdit.Text) ? null : _editorPanel.BasicEditor.NotesEdit.Text.Trim();
            if (useGraph && envelope.GraphId != null)
                EnsureGraphExists(_currentProject, envelope.GraphId, _selectedBrowserItem.Kind, _selectedBrowserItem.EntityId);
            PersistGraphJsonIfPresent(updateActionOnSuccess: false);
            ModStudioBootstrap.ProjectStore.Save(_currentProject);
            _projects = SafeGetProjects();
            _topBar?.SetProjects(_projects, _currentProject.Manifest.ProjectId);
            UpdateProjectDetails();
            SyncOverrideEditor();
            ClearUiDirty();
            SetAction(LF("status.saved_override", ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind), _selectedBrowserItem.EntityId));
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to save override: {ex.Message}");
            SetAction(LF("status.save_override_failed", ex.Message));
        }
    }

    private void RemoveCurrentOverride()
    {
        if (_currentProject == null)
        {
            SetAction(L("status.select_project_before_remove_override"));
            return;
        }
        if (_selectedBrowserItem == null)
        {
            SetAction(L("status.select_object_before_remove_override"));
            return;
        }
        var removed = _currentProject.Overrides.RemoveAll(x => x.EntityKind == _selectedBrowserItem.Kind && x.EntityId == _selectedBrowserItem.EntityId);
        if (removed == 0)
        {
            SetAction(LF("status.no_override_exists", ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind), _selectedBrowserItem.EntityId));
            return;
        }
        ModStudioBootstrap.ProjectStore.Save(_currentProject);
        UpdateProjectDetails();
        SyncOverrideEditor();
        ClearUiDirty();
        SetAction(LF("status.removed_override", ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind), _selectedBrowserItem.EntityId));
    }

    private void CaptureSelectedRuntimeMetadata()
    {
        if (_selectedBrowserItem == null || _editorPanel == null)
        {
            SetAction(L("status.capture_runtime_missing_selection"));
            return;
        }
        if (_selectedBrowserItem.IsProjectOnly || !ModStudioBootstrap.ModelMetadataService.HasRuntimeEntity(_selectedBrowserItem.Kind, _selectedBrowserItem.EntityId))
        {
            SetAction(L("status.capture_runtime_unavailable_project_entry"));
            return;
        }
        _editorPanel.BasicEditor.MetadataEdit.Text = JsonSerializer.Serialize(ModStudioBootstrap.ModelMetadataService.GetEditableMetadata(_selectedBrowserItem.Kind, _selectedBrowserItem.EntityId), ModStudioJson.Options);
        MarkUiDirty();
        SetAction(LF("status.capture_runtime_done", ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind), _selectedBrowserItem.EntityId));
    }

    private void ApplyEventTemplateScaffold()
    {
        if (_currentProject == null)
        {
            SetAction(L("status.select_project_before_event_template"));
            return;
        }
        if (_selectedBrowserItem == null || _selectedBrowserItem.Kind != ModStudioEntityKind.Event || _editorPanel == null)
        {
            SetAction(L("status.event_template_only"));
            return;
        }
        try
        {
            var metadata = GetEffectiveMetadataForSelectedItem();
            metadata["event_start_page_id"] = "INITIAL";
            metadata["event_page.INITIAL.description"] = metadata.TryGetValue("initial_description", out var initialDescription) && !string.IsNullOrWhiteSpace(initialDescription)
                ? initialDescription
                : L("event_template.default_initial_description");
            metadata["event_page.INITIAL.option_order"] = "CONTINUE";
            metadata["event_option.INITIAL.CONTINUE.title"] = L("event_template.default_option_continue_title");
            metadata["event_option.INITIAL.CONTINUE.description"] = L("event_template.default_option_continue_description");
            metadata["event_option.INITIAL.CONTINUE.next_page_id"] = "DONE";
            metadata["event_page.DONE.description"] = L("event_template.default_done_description");
            _editorPanel.BasicEditor.MetadataEdit.Text = JsonSerializer.Serialize(metadata, ModStudioJson.Options);
            MarkUiDirty();
            SetAction(LF("status.event_template_scaffold_applied", _selectedBrowserItem.EntityId));
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to apply event template scaffold: {ex.Message}");
            SetAction(LF("status.event_template_scaffold_failed", ex.Message));
        }
    }

    private void CreateNewProject()
    {
        try
        {
            _currentProject = ModStudioBootstrap.ProjectStore.CreateProject(LF("project.default_name", DateTimeOffset.Now.ToString("yyyy-MM-dd HH-mm-ss")));
            _projects = SafeGetProjects();
            _topBar?.SetProjects(_projects, _currentProject.Manifest.ProjectId);
            SelectBrowserKind(_selectedKind, false);
            UpdateProjectDetails();
            SyncOverrideEditor();
            ClearUiDirty();
            SetAction(LF("status.project_created", _currentProject.Manifest.Name));
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to create project: {ex.Message}");
            SetAction(LF("status.create_project_failed", ex.Message));
        }
    }

    private void OpenProject(string projectId)
    {
        if (!ModStudioBootstrap.ProjectStore.TryLoad(projectId, out var project) || project == null)
        {
            SetAction(LF("status.project_open_failed", projectId));
            return;
        }
        _currentProject = project;
        _topBar?.SetProjects(_projects, _currentProject.Manifest.ProjectId);
        SelectBrowserKind(_selectedKind, true);
        UpdateProjectDetails();
        SyncOverrideEditor();
        ClearUiDirty();
        SetAction(LF("status.project_opened", project.Manifest.Name));
    }

    private void ExportCurrentProject()
    {
        if (_currentProject == null)
        {
            SetAction(L("status.select_project_before_export"));
            return;
        }
        try
        {
            var path = ModStudioBootstrap.PackageStore.ExportProject(_currentProject, new PackageExportOptions
            {
                DisplayName = _currentProject.Manifest.Name,
                Author = _currentProject.Manifest.Author,
                Description = _currentProject.Manifest.Description,
                EditorVersion = _currentProject.Manifest.EditorVersion,
                TargetGameVersion = _currentProject.Manifest.TargetGameVersion
            });
            var install = ModStudioBootstrap.RuntimeRegistry.ImportPackage(path);
            _packages = SafeGetPackages();
            _selectedPackage = _packages.FirstOrDefault(x => x.PackageKey == install.PackageState.PackageKey);
            _packagePage?.SetPackages(_packages, _selectedPackage?.PackageKey);
            UpdatePackageDetails();
            SetAction(LF("status.exported_and_installed", _currentProject.Manifest.Name, path));
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to export project: {ex.Message}");
            SetAction(LF("status.export_failed", ex.Message));
        }
    }

    private void CreateNewEntryForSelectedKind()
    {
        if (_currentProject == null)
        {
            SetAction(L("status.select_project_before_new_entry"));
            return;
        }
        if (_selectedKind is ModStudioEntityKind.Character or ModStudioEntityKind.Monster)
        {
            SetAction(LF("status.new_entry_unsupported", ModStudioLocalization.GetEntityKindDisplayName(_selectedKind)));
            return;
        }
        try
        {
            var entityId = ModStudioBootstrap.ModelMetadataService.GenerateProjectEntityId(_currentProject, _selectedKind);
            var metadata = new Dictionary<string, string>(ModStudioBootstrap.ModelMetadataService.CreateDefaultMetadata(_selectedKind, entityId), StringComparer.Ordinal);
            var behaviorSource = _selectedKind == ModStudioEntityKind.Event ? BehaviorSource.Native : BehaviorSource.Graph;
            var graphId = behaviorSource == BehaviorSource.Graph ? BuildDefaultGraphId(_selectedKind, entityId) : null;
            var envelope = new EntityOverrideEnvelope
            {
                EntityKind = _selectedKind,
                EntityId = entityId,
                BehaviorSource = behaviorSource,
                GraphId = graphId,
                Metadata = metadata,
                Notes = L("default.entry_notes")
            };
            _currentProject.Overrides.Add(envelope);
            if (behaviorSource == BehaviorSource.Graph && graphId != null)
                EnsureGraphExists(_currentProject, graphId, _selectedKind, entityId);
            ModStudioBootstrap.ProjectStore.Save(_currentProject);
            _projects = SafeGetProjects();
            _topBar?.SetProjects(_projects, _currentProject.Manifest.ProjectId);
            UpdateProjectDetails();
            _selectedBrowserItem = new EntityBrowserItem { Kind = _selectedKind, EntityId = entityId, IsProjectOnly = true };
            SelectBrowserKind(_selectedKind, true);
            ClearUiDirty();
            SetAction(LF("status.created_entry", ModStudioLocalization.GetEntityKindDisplayName(_selectedKind), entityId));
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to create new entry: {ex.Message}");
            SetAction(LF("status.create_entry_failed", ex.Message));
        }
    }

    private void ShowPackageImportDialog()
    {
        if (_packageImportDialog == null)
        {
            SetAction(L("status.package_dialog_unavailable"));
            return;
        }
        _packageImportDialog.PopupCenteredRatio(0.75f);
    }

    private void OnPackageImportSelected(string packageFilePath)
    {
        try
        {
            var install = ModStudioBootstrap.RuntimeRegistry.ImportPackage(packageFilePath);
            _packages = SafeGetPackages();
            _selectedPackage = _packages.FirstOrDefault(x => x.PackageKey == install.PackageState.PackageKey);
            _packagePage?.SetPackages(_packages, _selectedPackage?.PackageKey);
            UpdatePackageDetails();
            SetAction(LF("status.package_imported", install.PackageState.DisplayName));
        }
        catch (Exception ex)
        {
            Log.Warn($"Failed to import package: {ex.Message}");
            SetAction(LF("status.package_import_failed", ex.Message));
        }
    }

    private void RefreshPackages()
    {
        ModStudioBootstrap.RuntimeRegistry.Refresh();
        _packages = SafeGetPackages();
        _selectedPackage = _packages.FirstOrDefault(x => x.PackageKey == _selectedPackage?.PackageKey) ?? _packages.FirstOrDefault();
        _packagePage?.SetPackages(_packages, _selectedPackage?.PackageKey);
        UpdatePackageDetails();
        SetAction(L("status.package_catalog_refreshed"));
    }

    private void ToggleSelectedPackage()
    {
        if (_selectedPackage == null)
        {
            SetAction(L("status.select_package_before_toggle"));
            return;
        }
        ModStudioBootstrap.RuntimeRegistry.EnablePackage(_selectedPackage.PackageKey, !_selectedPackage.Enabled);
        _packages = SafeGetPackages();
        _selectedPackage = _packages.FirstOrDefault(x => x.PackageKey == _selectedPackage.PackageKey);
        _packagePage?.SetPackages(_packages, _selectedPackage?.PackageKey);
        UpdatePackageDetails();
        SetAction(LF("status.toggled_package", _selectedPackage?.DisplayName ?? L("misc.unknown")));
    }

    private void MoveSelectedPackage(int direction)
    {
        if (_selectedPackage == null)
        {
            SetAction(L("status.select_package_before_reorder"));
            return;
        }
        if (!ModStudioBootstrap.RuntimeRegistry.MovePackage(_selectedPackage.PackageKey, direction))
        {
            SetAction(L("status.package_order_unchanged"));
            return;
        }
        _packages = SafeGetPackages();
        _selectedPackage = _packages.FirstOrDefault(x => x.PackageKey == _selectedPackage.PackageKey);
        _packagePage?.SetPackages(_packages, _selectedPackage?.PackageKey);
        UpdatePackageDetails();
        SetAction(LF("status.moved_package", _selectedPackage?.DisplayName ?? L("misc.unknown")));
    }

    private void OnPackageSelected(string packageKey)
    {
        _selectedPackage = _packages.FirstOrDefault(x => x.PackageKey == packageKey);
        _packagePage?.SetPackages(_packages, _selectedPackage?.PackageKey);
        UpdatePackageDetails();
        UpdateStateText();
    }

    private void RequestCloseModStudio()
    {
        if (_hasPendingUiChanges)
        {
            _closeDialog?.Show();
            return;
        }
        CloseModStudioNow();
    }

    private void SaveAndCloseModStudio()
    {
        if (_currentProject != null && _selectedBrowserItem != null)
            SaveCurrentOverride();
        else if (_currentProject != null)
            ModStudioBootstrap.ProjectStore.Save(_currentProject);
        _hasPendingUiChanges = false;
        CloseModStudioNow();
    }

    private void DiscardAndCloseModStudio()
    {
        _hasPendingUiChanges = false;
        CloseModStudioNow();
    }

    private void CancelCloseModStudio()
    {
        _closeDialog?.Hide();
    }

    private void CloseModStudioNow()
    {
        _closeDialog?.Hide();
        _hasPendingUiChanges = false;
        RefreshData();
        _stack?.Pop();
    }

    private void MarkUiDirty()
    {
        _hasPendingUiChanges = true;
        UpdateStateText();
    }

    private void ClearUiDirty()
    {
        _hasPendingUiChanges = false;
        UpdateStateText();
    }

    private void UpdateStateText()
    {
        var mode = _isProjectMode ? L("tab.project_mode") : L("tab.package_mode");
        var selected = _selectedBrowserItem != null ? $"{ModStudioLocalization.GetEntityKindDisplayName(_selectedBrowserItem.Kind)}:{_selectedBrowserItem.EntityId}" : _selectedPackage?.PackageKey ?? L("state.none");
        var project = _currentProject?.Manifest.Name ?? L("state.none");
        var statusText = LF("state.mode", mode, project, _packages.Count, selected, _lastAction);
        _topBar?.SetState(statusText);
    }

    private void SetAction(string message)
    {
        _lastAction = message;
        UpdateStateText();
    }

    private void OnMetadataJsonTextChanged(string _)
    {
        if (_suppressMetadataJsonChanged)
            return;
        RefreshAssetEditor();
        MarkUiDirty();
    }

    private static string ResolveGraphJsonText(EditorProject? project, EntityOverrideEnvelope? envelope, ModStudioEntityKind kind)
    {
        if (project == null || envelope?.GraphId == null)
            return string.Empty;
        if (!project.Graphs.TryGetValue(envelope.GraphId, out var graph))
            return string.Empty;
        graph.EntityKind ??= kind;
        return JsonSerializer.Serialize(graph, ModStudioJson.Options);
    }

    private static void EnsureGraphExists(EditorProject project, string graphId, ModStudioEntityKind kind, string entityId)
    {
        if (project.Graphs.ContainsKey(graphId))
            return;
        project.Graphs[graphId] = ModStudioGraphUiHelpers.CreateScaffoldGraph(kind, graphId, entityId);
    }

    private static string BuildDefaultGraphId(ModStudioEntityKind kind, string entityId)
    {
        var normalizedId = entityId.Replace(':', '_').Replace('/', '_').Replace('\\', '_');
        return $"graph.{kind.ToString().ToLowerInvariant()}.{normalizedId}";
    }

    private static Dictionary<string, string> ParseMetadata(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return new Dictionary<string, string>(StringComparer.Ordinal);
        return JsonSerializer.Deserialize<Dictionary<string, string>>(json, ModStudioJson.Options) ?? new Dictionary<string, string>(StringComparer.Ordinal);
    }

    private static string FormatMetadataFieldLabel(string key)
    {
        return string.IsNullOrWhiteSpace(key) ? string.Empty : key.Replace('_', ' ');
    }

    private static int GetMetadataFieldPriority(string key)
    {
        return key switch
        {
            "title" => 0,
            "description" => 1,
            "type" => 2,
            "rarity" => 3,
            "pool_id" => 4,
            "target_type" => 5,
            "energy_cost" => 6,
            "energy_cost_x" => 7,
            "canonical_star_cost" => 8,
            "star_cost_x" => 9,
            "usage" => 10,
            "layout_type" => 11,
            "is_shared" => 12,
            "portrait_path" => 13,
            "icon_path" => 14,
            "image_path" => 15,
            "initial_description" => 16,
            _ => 100
        };
    }

    private static void ConfigureOverlayControl(Control control)
    {
        control.SetAnchorsPreset(LayoutPreset.FullRect);
        control.OffsetLeft = 0f;
        control.OffsetTop = 0f;
        control.OffsetRight = 0f;
        control.OffsetBottom = 0f;
        control.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        control.SizeFlagsVertical = SizeFlags.ExpandFill;
    }
}
