using Godot;
using static STS2_Editor.Scripts.Editor.UI.ModStudioUiFactory;

namespace STS2_Editor.Scripts.Editor.UI;

internal sealed partial class ModStudioGraphEditor : MarginContainer
{
    public ModStudioGraphCanvasView CanvasView { get; private set; } = null!;

    public override void _Ready()
    {
        CanvasView = new ModStudioGraphCanvasView
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill
        };
        AddChild(CanvasView);
    }
}
